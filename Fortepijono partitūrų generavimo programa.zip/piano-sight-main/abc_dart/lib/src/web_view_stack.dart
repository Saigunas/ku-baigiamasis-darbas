import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebViewStack extends StatefulWidget {
  const WebViewStack({super.key, required this.controller, this.onPageFinished});

  final WebViewController controller;
  final VoidCallback? onPageFinished; // Callback to notify when DOM is ready

  @override
  State<WebViewStack> createState() => _WebViewStackState();
}

class _WebViewStackState extends State<WebViewStack> {

  @override
  void initState() {
    super.initState();

    widget.controller
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            setState(() {
              //
            });
          },
          onProgress: (progress) {
            setState(() {
              //
            });
          },
          onPageFinished: (url) {
            // Notify that the page is fully loaded
            if (widget.onPageFinished != null) {
              widget.onPageFinished!();
            }          
          },
        ),
      )
      ..setJavaScriptMode(JavaScriptMode.unrestricted);
  }


  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        WebViewWidget(
          controller: widget.controller,
        ),
      ],
    );
  }
}

