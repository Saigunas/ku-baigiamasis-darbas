import 'package:webview_flutter/webview_flutter.dart';

class SheetMusicViewerController {
  final WebViewController webViewController;
  
  SheetMusicViewerController({
    required this.webViewController,
  });

  displaySheetMusic(String sheetMusic, { int transposeStep = 0 }) {
    webViewController.runJavaScript("updateSheetData(`$sheetMusic`, $transposeStep)");
    return;
  }

  stopSheetMusicPlayer() {
    webViewController.runJavaScript("stopSynth()");
    return;
  }
}