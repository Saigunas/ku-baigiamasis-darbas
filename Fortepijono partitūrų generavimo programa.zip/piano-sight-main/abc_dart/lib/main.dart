library;

import 'package:abc_dart/src/controllers/sheet_music_viewer_controller.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'src/web_view_stack.dart';


void main() {
  runApp(
    MaterialApp(
      home: const WebViewApp(),
    ),
  );
}

class WebViewApp extends StatefulWidget {
  final Function(SheetMusicViewerController)? onControllerCreated;
  final VoidCallback? onPageFinished;

  const WebViewApp({super.key, this.onControllerCreated, this.onPageFinished});

  @override
  State<WebViewApp> createState() => _WebViewAppState();
}

class _WebViewAppState extends State<WebViewApp> {
  late final WebViewController controller;

  @override
  void initState() {
    super.initState();
    controller = WebViewController();
    // Load local HTML file in the WebView
    controller.loadFlutterAsset('packages/abc_dart/assets/www/index.html').whenComplete(() => null);

    // Pass the controller back to the parent via the callback
    if (widget.onControllerCreated != null) {
      SheetMusicViewerController sheetMusicViewerController = SheetMusicViewerController(webViewController: controller);
      widget.onControllerCreated!(sheetMusicViewerController);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: WebViewStack(controller: controller, onPageFinished: widget.onPageFinished),
    );
  }
}
