document.addEventListener("DOMContentLoaded", function() {
});

let previousSynthControl;
function renderSheet(sheetData, transposeStep = 0) {
    if(previousSynthControl) {
        previousSynthControl.pause();
    }

    let synthControl = new ABCJS.synth.SynthController();
    synthControl.load(
        "#audio",
        { 
            displayLoop: false, 
            displayRestart: false, 
            displayPlay: true, 
            displayProgress: true, 
            displayWarp: false,
        }
    );

    const visualOptions = { responsive: 'resize', visualTranspose: transposeStep };
    let visualObj = ABCJS.renderAbc("paper", sheetData, visualOptions);

    if(visualObj) {
        let audioParams = {
            midiTranspose: transposeStep
        };
        synthControl.setTune(visualObj[0], false, audioParams);
    }
    previousSynthControl = synthControl;
}

function stopSynth() {
    previousSynthControl.pause();
}

function updateSheetData(sheetData, transposeStep = 0) {
    renderSheet(sheetData, transposeStep);
}
