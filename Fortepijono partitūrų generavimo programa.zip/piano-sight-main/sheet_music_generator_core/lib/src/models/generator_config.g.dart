// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'generator_config.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GeneratorConfig _$GeneratorConfigFromJson(Map<String, dynamic> json) =>
    GeneratorConfig(
      style: $enumDecode(_$StyleEnumMap, json['style']),
      difficulty: $enumDecode(_$DifficultyEnumMap, json['difficulty']),
    );

Map<String, dynamic> _$GeneratorConfigToJson(GeneratorConfig instance) =>
    <String, dynamic>{
      'style': _$StyleEnumMap[instance.style]!,
      'difficulty': _$DifficultyEnumMap[instance.difficulty]!,
    };

const _$StyleEnumMap = {
  Style.classical: 'classical',
  Style.anime: 'anime',
};

const _$DifficultyEnumMap = {
  Difficulty.one: 'one',
  Difficulty.two: 'two',
  Difficulty.three: 'three',
  Difficulty.four: 'four',
};
