import '../data/enums.dart';
import 'package:json_annotation/json_annotation.dart';

part 'generator_config.g.dart';

/// Configuration for sheet music generator

@JsonSerializable()
class GeneratorConfig {
  Style style;
  Difficulty difficulty;

  GeneratorConfig({
    required this.style,
    required this.difficulty,
  });

  // Factory constructor for creating a new instance from JSON
  factory GeneratorConfig.fromJson(Map<String, dynamic> json) =>
      _$GeneratorConfigFromJson(json);

  // Method for converting an instance to JSON
  Map<String, dynamic> toJson() => _$GeneratorConfigToJson(this);
}
