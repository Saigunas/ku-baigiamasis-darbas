import '../data/enums.dart';

/// Configuration for sheet music key elements
class SheetMusicConfig {
  KeyType keyType;
  Bars bars;
  Time time;
  List<Clef> clefs;
  int barsPerLine = 4;
  int lineCount = 2;

  SheetMusicConfig({
    required this.keyType,
    required this.bars,
    required this.time,
    required this.clefs,
  });
}
