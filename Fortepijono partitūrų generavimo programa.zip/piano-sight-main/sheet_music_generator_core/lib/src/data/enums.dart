

enum Clef {
  treble,
  bass,
}

extension ClefExtension on Clef {
  String get value {
    switch (this) {
      case Clef.treble:
        return 'treble';
      case Clef.bass:
        return 'bass';
    }
  }
}

enum KeyType {
  major,
  minor,
}

enum Bars {
  one,
  two,
  four,
  eight,
  sixteen,
}

extension BarsExtension on Bars {
  int get value {
    switch (this) {
      case Bars.one:
        return 1;
      case Bars.two:
        return 2;
      case Bars.four:
        return 4;
      case Bars.eight:
        return 8;
      case Bars.sixteen:
        return 16;
    }
  }
}

enum Time {
  four_four,
  three_four,
  two_four,
  six_eight,
  twelve_eight,
  nine_eight,
  five_four,
  seven_four,
  two_two,
}

extension TimeExtension on Time {
  int get beats {
    switch (this) {
      case Time.four_four:
        return 4;
      case Time.three_four:
        return 3;
      case Time.two_four:
        return 2;
      case Time.six_eight:
        return 6;
      case Time.twelve_eight:
        return 12;
      case Time.nine_eight:
        return 9;
      case Time.five_four:
        return 5;
      case Time.seven_four:
        return 7;
      case Time.two_two:
        return 2;
    }
  }
  int get beatUnit {
    switch (this) {
      case Time.four_four:
        return 4;
      case Time.three_four:
        return 4;
      case Time.two_four:
        return 4;
      case Time.six_eight:
        return 8;
      case Time.twelve_eight:
        return 8;
      case Time.nine_eight:
        return 8;
      case Time.five_four:
        return 4;
      case Time.seven_four:
        return 4;
      case Time.two_two:
        return 2;
    }
  }
}

enum Style {
  classical,
  anime
}

extension StyleExtension on Style {
  String get styleName {
    switch (this) {
      case Style.classical:
        return 'Classical';
      case Style.anime:
        return 'Anime';
    }
  }
}

enum Difficulty {
  one,
  two,
  three,
  four,
}

extension DifficultyExtension on Difficulty {
  int get level {
    switch (this) {
      case Difficulty.one:
        return 1;
      case Difficulty.two:
        return 2;
      case Difficulty.three:
        return 3;
      case Difficulty.four:
        return 4;
    }
  }
}