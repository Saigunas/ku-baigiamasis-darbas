import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:test/expect.dart';
import 'package:test/scaffolding.dart';

void main() {
  group('GeneratorConfig JSON Serialization', () {
    test('fromJson should correctly deserialize JSON to GeneratorConfig', () {
      // Sample JSON data
      final Map<String, dynamic> json = {
        "style": "pop",
        "difficulty": "one"
      };

      // Deserialize JSON to GeneratorConfig
      final config = GeneratorConfig.fromJson(json);

      // Assert the deserialized values
      expect(config.style, Style.pop);
      expect(config.difficulty, Difficulty.one);
    });

    test('toJson should correctly serialize GeneratorConfig to JSON', () {
      // Create an instance of GeneratorConfig
      final config = GeneratorConfig(
        style: Style.pop,
        difficulty: Difficulty.one,
      );

      // Serialize the GeneratorConfig to JSON
      final json = config.toJson();

      // Assert the serialized values
      expect(json["style"], "pop");
      expect(json["difficulty"], "one");
    });
  });
}
