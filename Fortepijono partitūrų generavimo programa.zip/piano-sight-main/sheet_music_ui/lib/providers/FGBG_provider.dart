import 'package:flutter/material.dart';
import 'package:flutter_fgbg/flutter_fgbg.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:storage/storage.dart';

class FGBGProvider with ChangeNotifier {
  // Singleton boilerplate
  static final FGBGProvider _singleton = FGBGProvider._internal();
  factory FGBGProvider() {
    return _singleton;
  }
  FGBGProvider._internal();
  
  final List<VoidCallback> _listeners = [];

  // Function to add listeners
  void addListenerCallback(VoidCallback callback) {
    _listeners.add(callback);
  }

  // Function to remove listeners
  void removeListenerCallback(VoidCallback callback) {
    _listeners.remove(callback);
  }


  Future<void> onFGBGChange(FGBGType type) async {
    notifyListeners();

    // Execute registered callbacks
    for (var callback in _listeners) {
      callback();
    }
  }

}