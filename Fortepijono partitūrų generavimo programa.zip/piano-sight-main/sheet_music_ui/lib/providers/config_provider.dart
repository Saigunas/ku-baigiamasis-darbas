import 'package:flutter/material.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:storage/storage.dart';

class ConfigProvider with ChangeNotifier {
  // Singleton boilerplate
  static final ConfigProvider _singleton = ConfigProvider._internal();
  factory ConfigProvider() {
    return _singleton;
  }
  ConfigProvider._internal();
  
  // Provide a default value here
  GeneratorConfig _config = GeneratorConfig(
    style: Style.classical,
    difficulty: Difficulty.one,
  );

  GeneratorConfig get config => _config;
  // Method to load the config asynchronously

  Future<void> loadConfig() async {
    final savedConfig = await ConfigService.loadConfig();
    if (savedConfig != null) {
      _config = savedConfig;
      notifyListeners(); // Notify listeners that _config has been updated
    }
  }

  Future<void> updateDifficulty(Difficulty newDifficulty) async {
    _config.difficulty = newDifficulty;
    await ConfigService.saveConfig(_config);
    notifyListeners(); // Notifies any listeners about the change
  }

  Future<void> updateStyle(Style newStyle) async {
    _config.style = newStyle;
    await ConfigService.saveConfig(_config);
    notifyListeners(); // Notifies any listeners about the change
  }

  Future<void> updateConfig(GeneratorConfig newConfig) async {
    _config = newConfig;
    await ConfigService.saveConfig(_config);
    notifyListeners(); // Notifies any listeners about the change
  }
}