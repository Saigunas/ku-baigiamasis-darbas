import 'package:flutter/material.dart';

abstract class AppColors {
  static const Color selectedBtn = Color(0xff8e8e8e);

  static const Color pianosightPlus = Color(0xff381c5c);
}