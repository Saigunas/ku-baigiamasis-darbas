import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTextStyles {
  static TextStyle primary = GoogleFonts.nunito(
    fontSize: 20,
    fontWeight: FontWeight.w500,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle secondary = GoogleFonts.nunito(
    fontSize: 16,
    fontWeight: FontWeight.w500,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle header = GoogleFonts.nunito(
    fontSize: 48,
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle defaultSemiBold = GoogleFonts.nunito(
    fontSize: 20,
    fontWeight: FontWeight.w700,
    height: 7.5,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle secondaryBold = GoogleFonts.nunito(
    fontSize: 16,
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle header2 = GoogleFonts.nunito(
    fontSize: 28,
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle logo = GoogleFonts.poppins(
    fontSize: 48,
    fontWeight: FontWeight.w500,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle defaultBold = GoogleFonts.nunito(
    fontSize: 20,
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle logoMedium = GoogleFonts.poppins(
    fontSize: 28,
    fontWeight: FontWeight.w500,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle levelSelection = GoogleFonts.ubuntuMono(
    fontSize: 48,
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );

  static TextStyle pianosightPlus = GoogleFonts.nunitoSans(
    fontSize: 24,
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
    decoration: TextDecoration.none,
  );
}
