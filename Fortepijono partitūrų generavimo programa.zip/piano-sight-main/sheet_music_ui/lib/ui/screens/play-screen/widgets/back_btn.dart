import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sheet_music_ui/ui/constants/app_text_styles.dart';
import 'package:sheet_music_ui/ui/screens/home/home_screen.dart';

class BackBtn extends StatelessWidget {
  const BackBtn({
    super.key,
    required this.generatorSettingString,
  });

  final String generatorSettingString;

  @override
  Widget build(BuildContext context) {
    return TextButton(
      style: TextButton.styleFrom(
        foregroundColor: Colors.black,                  
      ),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
      },
      child: Padding(
        padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
        child: Row(
            children: [
              const Icon(
                Icons.chevron_left,
                color: Colors.black,
                size: 35.0,
              ),
              const Gap(0),
              Text(
                generatorSettingString,
                style: AppTextStyles.primary,
              ),
            ]
        ),
      ),
    );
  }
}
