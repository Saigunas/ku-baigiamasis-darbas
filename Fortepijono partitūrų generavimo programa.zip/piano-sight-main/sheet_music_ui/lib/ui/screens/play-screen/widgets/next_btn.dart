import 'package:flutter/material.dart';
import 'package:sheet_music_ui/ui/constants/app_text_styles.dart';

class NextBtn extends StatelessWidget {
  final void Function() onPressed;

  const NextBtn({
    super.key,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return UnconstrainedBox (
      child: TextButton(
        style: TextButton.styleFrom(
          foregroundColor: Colors.white,
          backgroundColor: Colors.black,
          
        ),
        onPressed: onPressed,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(40, 0, 40, 0),
          child: Row(
              children: [
                Text(
                  'NEXT',
                  style: AppTextStyles.defaultBold,
                ),
              ]
          ),
        ),
      ),
    );
  }
}
