import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:sheet_music_ui/providers/FGBG_provider.dart';
import 'package:sheet_music_ui/providers/config_provider.dart';
import 'package:sheet_music_ui/src/sheet-music-generator/sheet-music.dart';
import 'package:sheet_music_ui/ui/screens/play-screen/widgets/back_btn.dart';
import 'package:sheet_music_ui/ui/screens/play-screen/widgets/next_btn.dart';

class PlayScreen extends StatelessWidget {
  final SheetMusic _sheetMusic = SheetMusic();

  @override
  Widget build(BuildContext context) {
  final configProvider = Provider.of<ConfigProvider>(context);

  // Register a listener for pausing sheet music
  final fgbgProvider = Provider.of<FGBGProvider>(context, listen: false);
  fgbgProvider.removeListenerCallback(_sheetMusic.stopSheetMusicPlayer);
  fgbgProvider.addListenerCallback(_sheetMusic.stopSheetMusicPlayer);

  final String generatorSettingString = 'Lvl ${configProvider.config.difficulty.level.toString()}, ${configProvider.config.style.styleName}';

    return Scaffold(
      appBar: AppBar(
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(0),
          child: Row(
            children: [
              Expanded( 
                child: Row(
                  children: [
                    BackBtn(generatorSettingString: generatorSettingString),
                    Expanded(child: Container(),),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.center, 
                child: NextBtn(
                  onPressed: _sheetMusic.generateSheetMusic,
                )
              ),
              Expanded(
                child: Container(),
              ),
            ],
          ),
        ),
      ),
      body: Container(
        child: _sheetMusic,
      ),
    );
  }
}
