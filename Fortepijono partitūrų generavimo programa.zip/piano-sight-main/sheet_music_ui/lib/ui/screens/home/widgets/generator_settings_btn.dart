import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:sheet_music_ui/providers/config_provider.dart';
import 'package:sheet_music_ui/ui/constants/app_text_styles.dart';
import 'package:sheet_music_ui/ui/screens/generator-settings/generator_settings_screen.dart';

class GeneratorSettingsBtn extends StatelessWidget {
  const GeneratorSettingsBtn({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final configProvider = Provider.of<ConfigProvider>(context);
    return UnconstrainedBox (
      child: TextButton(
        style: TextButton.styleFrom(
          foregroundColor: Colors.white,
          backgroundColor: Colors.black,
          
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => GeneratorSettingsScreen()),
          );
        },
        child: Padding(
          padding: const EdgeInsets.fromLTRB(40, 0, 40, 0),
          child: Row(
              children: [
                Text(
                  'Lvl ${configProvider.config.difficulty.level.toString()}, ${configProvider.config.style.styleName}',
                  style: AppTextStyles.secondaryBold,
                )
              ]
          ),
        ),
      ),
    );
  }
}
