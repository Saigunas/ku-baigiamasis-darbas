import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';
import 'package:sheet_music_ui/ui/constants/app_text_styles.dart';
import 'package:sheet_music_ui/ui/screens/home/widgets/generator_settings_btn.dart';
import 'package:sheet_music_ui/ui/screens/home/widgets/play_btn_big.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/images/backgrounds/blurred-empty-staves-heavy.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Container(
                // color: Colors.cyan,
                constraints: const BoxConstraints.expand(),
                child: Column(
                  children: [
                  Column(
                      children: 
                      [
                        Align(
                          alignment: Alignment.topCenter,
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(0, 0, 0, 25),
                            child: Text(
                              'PianoSight',
                              style: AppTextStyles.logo,
                            ),
                          )
                        ),
                      ],
                    ),
                    const Expanded(
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(0, 0, 20, 0),
                        child: Image(
                          image: AssetImage("assets/images/mascot/home-screen-logo.png"), 
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  ]
                ),
              ),
            ),
            Expanded(
              child: Container(
                // color: Colors.blue,
                constraints: const BoxConstraints.expand(),
                child: Column(
                  children: [
                    Expanded(
                      child: Container(),
                      /*Align(
                    
                        alignment: Alignment.topCenter,
                        child: DefaultTextStyle.merge(
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                          child: const Text('Daily  Goal:'),
                        ),
                      ),
                    */
                    ),
                    const PlayBtnBig(),
                    const Expanded(
                      child: Column(
                        children: [
                          Gap(10),
                          GeneratorSettingsBtn(),
                        ],
                      )
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

