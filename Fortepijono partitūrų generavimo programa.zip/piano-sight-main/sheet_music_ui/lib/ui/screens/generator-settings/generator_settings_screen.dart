import 'package:flutter/material.dart';
import 'package:sheet_music_ui/ui/screens/generator-settings/tab-views/level_setting_tab_view.dart';
import 'package:sheet_music_ui/ui/screens/generator-settings/tab-views/style_setting_tab_view.dart';
import 'package:sheet_music_ui/ui/screens/generator-settings/widgets/tab_item.dart';
import 'package:sheet_music_ui/ui/screens/home/home_screen.dart';

class GeneratorSettingsScreen extends StatelessWidget {
  GeneratorSettingsScreen({
    super.key,
  });

  static const double tabItemPadding = 10;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          bottom: const PreferredSize(
            preferredSize: Size.fromHeight(0),
            child: Row(
              children: [
                PrevPageBtn(),
                Expanded(
                  child: TabBar(
                    indicatorColor: Colors.black,
                    unselectedLabelColor: Colors.grey,
                    labelColor: Colors.black,
                    tabs: [
                      Tab(
                        child: TabItem(title: 'Level'),
                      ),
                      Tab(
                        child: TabItem(title: 'Style'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        body: TabBarView(
          children: [
            LevelSettingTabView(),
            StyleSettingTabView(),
          ],
        ),
      ),
    );
  }
}

class PrevPageBtn extends StatelessWidget {
  const PrevPageBtn({
    super.key,
  });

  @override
  Widget build(BuildContext context) {    
    return IconButton(
      icon: const Icon(
        Icons.chevron_left,
        color: Colors.black,
        size: 35.0,
      ),
      onPressed: () async {
        if (!context.mounted) return;
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
      },
    );
  }
}
