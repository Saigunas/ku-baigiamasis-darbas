import 'package:flutter/cupertino.dart';
import 'package:sheet_music_ui/ui/constants/app_text_styles.dart';

class TabItem extends StatelessWidget {
  final String title;

  const TabItem({
    super.key,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          title,
          style: AppTextStyles.defaultBold,
        ),
      ],
    );
  }
}
