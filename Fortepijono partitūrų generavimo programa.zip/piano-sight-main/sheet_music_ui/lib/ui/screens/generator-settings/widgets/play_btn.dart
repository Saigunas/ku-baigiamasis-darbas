import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sheet_music_ui/ui/constants/app_text_styles.dart';
import 'package:sheet_music_ui/ui/screens/play-screen/play_screen.dart';

class PlayBtn extends StatelessWidget {
  const PlayBtn({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return UnconstrainedBox (
      child: TextButton(
        style: TextButton.styleFrom(
          foregroundColor: Colors.white,
          backgroundColor: Colors.black,
          
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PlayScreen()),
          );
        },
        child: Padding(
          padding: const EdgeInsets.fromLTRB(40, 0, 30, 0),
          child: Row(
              children: [
                Text(
                  'PLAY',
                  style: AppTextStyles.defaultBold,
                ),
                const Gap(10),
                Image.asset(
                  "assets/images/btn-images/note.png", 
                  width: 18, 
                  height: 18,
                ),
              ]
          ),
        ),
      ),
    );
  }
}

