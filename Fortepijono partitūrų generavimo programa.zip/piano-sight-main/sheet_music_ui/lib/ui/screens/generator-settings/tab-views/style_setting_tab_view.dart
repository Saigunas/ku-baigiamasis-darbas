import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:provider/provider.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:sheet_music_ui/providers/config_provider.dart';
import 'package:sheet_music_ui/ui/constants/app_text_styles.dart';
import 'package:sheet_music_ui/ui/screens/generator-settings/widgets/play_btn.dart';

class StyleButtonData {
  final String label;
  final String assetPath;
  StyleButtonData(this.label, this.assetPath);
}

class StyleSettingTabView extends StatefulWidget {
  const StyleSettingTabView({
    super.key,
  });

  @override
  State<StyleSettingTabView> createState() => _StyleSettingTabViewState();
}

class _StyleSettingTabViewState extends State<StyleSettingTabView> {
  late ConfigProvider configProvider;
  late List<StyleButtonData> styleButtons;
  int selectedBtnIndex = 0;

  _StyleSettingTabViewState() {
    List<String> availableStyles = Style.values.map((e) => e.styleName).toList();
    // Define the btnLabels and assets to be displayed
    styleButtons = availableStyles.map(
      (style) {
        String styleLowerCase = style.toLowerCase();
        String assetPath = 'assets/images/style-preview/$styleLowerCase-preview.png';

        return StyleButtonData(style, assetPath);
      }
    ).toList();
  }

  @override
  void initState() {
    super.initState();

    // Access the provider once in initState without listening for rebuilds
    configProvider = Provider.of<ConfigProvider>(context, listen: false);
    selectedBtnIndex = configProvider.config.style.index;
  }


  @override
  Widget build(BuildContext context) {

    // Update selection to allow only one button to be active at a time
    void onControlPress(int index) {
      configProvider.updateStyle(Style.values[index]);
      setState(() {
        selectedBtnIndex = index;
      });
    }

    List<Widget> gridListItems = [];
    Row toggleBtnRow = const Row(children: [],);
    for (int i = 0; i < styleButtons.length; i++) {
      BorderRadius borderRadius = BorderRadius.circular(25);

      var toggleBtnItem = Padding(
        padding: const EdgeInsets.fromLTRB(55, 15, 55, 15),
        child: Text(
          styleButtons[i].label,
          style: AppTextStyles.defaultBold,
        ),
      );
      ToggleButtons toggleBtn = ToggleButtons(
        selectedColor: Colors.white,
        fillColor: Colors.black,
        color: Colors.white,
        borderColor: null,
        selectedBorderColor: Colors.white,
        borderWidth: 0, 
        borderRadius: borderRadius,

        isSelected: [i == selectedBtnIndex],
        onPressed: (_) => onControlPress(i),

        children: [toggleBtnItem],
      );

      Container togglebtnWrapper = Container(
        padding: EdgeInsets.zero,
        decoration: BoxDecoration(
          color: Colors.grey,
          borderRadius: borderRadius,
        ),
        child: toggleBtn
      );
    
      // Create a new row for every second item
      if(i % 2 == 0) {
        toggleBtnRow = Row(
          children: [],
        );
        gridListItems.add(
          toggleBtnRow
        );
        gridListItems.add(const Gap(18));
      }

      toggleBtnRow.children.add(togglebtnWrapper);

      // Except for last item
      if(i % 2 != 1) {
        toggleBtnRow.children.add(const Spacer());
      }
    }

    return Column(
      children: [
        Expanded(
          child: Row(
            children: [
              Flexible(
                flex: 10,
                child: Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(55, 70, 0, 0),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Column(
                      children: gridListItems,
                    )
                  ),
                ),
              ),
              Flexible(
                flex: 9,
                child: Padding(
                  padding:  const EdgeInsetsDirectional.fromSTEB(10, 0, 0, 0),
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: Image.asset(
                      fit: BoxFit.contain,
                      styleButtons[selectedBtnIndex].assetPath,
                    ),
                  ),
                ),
              )
            ], 
          ),
        ),
        SizedBox.fromSize(
          size: const Size.fromHeight(67),
        /*
          child: const Align(
            alignment: Alignment.topCenter,
            child: PlayBtn()
          ),
        */
        )
      ],
    );
  }
}
