import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:sheet_music_ui/providers/config_provider.dart';
import 'package:sheet_music_ui/ui/constants/app_text_styles.dart';

class LevelButtonData {
  final String label;
  final String assetPath;
  LevelButtonData(this.label, this.assetPath);
}

class LevelSettingTabView extends StatefulWidget {

  const LevelSettingTabView({
    super.key,
  });

  @override
  State<LevelSettingTabView> createState() => _LevelSettingTabViewState();
}

class _LevelSettingTabViewState extends State<LevelSettingTabView> {
  late ConfigProvider configProvider;
  late List<LevelButtonData> levelButtons;
  int selectedBtnIndex = 0;

  _LevelSettingTabViewState() {
    // Define the btnLabels and assets to be displayed
    levelButtons = [];
    // For each difficulty level create data for a button
    for(int i = 0; i < Difficulty.values.length; i++) {
      Difficulty currentDifficulty = Difficulty.values[i];

      String currentDifficultyString = currentDifficulty.name.toString();
      String assetPath = 'assets/images/level-preview/level-$currentDifficultyString-preview.png';
      
      String currentDifficultyNumber = currentDifficulty.level.toString();
      levelButtons.add(LevelButtonData(currentDifficultyNumber, assetPath));
    }
  }

  @override
  void initState() {
    super.initState();

    // Access the provider once in initState without listening for rebuilds
    configProvider = Provider.of<ConfigProvider>(context, listen: false);
    selectedBtnIndex = configProvider.config.difficulty.index;
  }

  // Define assets to display based on selected button
  // Prechache
  /*
  late List<Image>displayAsset;

  late Image lvlPreview1;
  late Image lvlPreview2;
  late Image lvlPreview3;
  late Image lvlPreview4;

  @override
  void initState() {
    super.initState();
    lvlPreview1 = LevelPreviewImage(assetPath: ('assets/images/level-preview/tmp.jpg'));
    lvlPreview2 = LevelPreviewImage(assetPath: ('assets/images/level-preview/tmp.jpg'));
    lvlPreview3 = LevelPreviewImage(assetPath: ('assets/images/level-preview/tmp.jpg'));
    lvlPreview4 = LevelPreviewImage(assetPath: ('assets/images/level-preview/tmp.jpg'));

    displayAsset = [
      lvlPreview1,
      lvlPreview2,
      lvlPreview3,
      lvlPreview4,
    ];
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    precacheImage(lvlPreview1.image, context);
    precacheImage(lvlPreview2.image, context);
    precacheImage(lvlPreview3.image, context);
    precacheImage(lvlPreview4.image, context);
  }
*/
  @override
  Widget build(BuildContext context) {
    // Update selection to allow only one button to be active at a time
    void onControlPress(int index) {
      configProvider.updateDifficulty(Difficulty.values[index]);
      setState(() {
        selectedBtnIndex = index;
      });
    }

    List<Widget> gridListItems = [];
    for (int i = 0; i < levelButtons.length; i++) {
      LevelButtonData levelButtonData = levelButtons[i];
      var toggleBtnItem = Text(
        levelButtonData.label,
        style: AppTextStyles.levelSelection,
      );

      BorderRadius borderRadius = BorderRadius.circular(8);

      ToggleButtons toggleBtn = ToggleButtons(
        selectedColor: Colors.white,
        fillColor: Colors.black,
        color: Colors.white,
        borderColor: null,
        selectedBorderColor: Colors.white,
        borderWidth: 0, 
        borderRadius: borderRadius,
        constraints: const BoxConstraints(minWidth: 68, minHeight: 68),

        isSelected: [i == selectedBtnIndex],
        onPressed: (_) => onControlPress(i),

        children: [toggleBtnItem],
      );

      Container togglebtnWrapper = Container(
        padding: EdgeInsets.zero,
        decoration: BoxDecoration(
          color: Colors.grey,
          borderRadius: borderRadius,
        ),
        child: toggleBtn
      );
      gridListItems.add(togglebtnWrapper);
    }

    return Row(
      children: [
        Expanded(
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(15, 70, 0, 0),
            child: Align(
              alignment: Alignment.topCenter,
              child: SizedBox(
                width: 280,
                child: Wrap(
                  direction: Axis.horizontal,
                  spacing: 35,
                  runSpacing: 25,
                  children: gridListItems,
                ),
              ),
            ),
          ),
        ),
        Expanded(child: Padding(
            padding:  const EdgeInsetsDirectional.fromSTEB(0, 0, 0, 20),
            child: Align(
              alignment: Alignment.center,
              child: LevelPreviewImage(assetPath: levelButtons[selectedBtnIndex].assetPath,),
            ),
          ),
        )
      ], 
    );
  }
}

class LevelPreviewImage extends Image {
  LevelPreviewImage({
    Key? key,
    required String assetPath,
    double height = 220.0,
    BoxFit fit = BoxFit.contain,
  }) : super.asset(
          assetPath,
          key: key,
          height: height,
          fit: fit,
        );
}