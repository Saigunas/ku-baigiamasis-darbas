import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_fgbg/flutter_fgbg.dart';
import 'package:provider/provider.dart';
import 'package:sheet_music_ui/providers/FGBG_provider.dart';
import 'package:sheet_music_ui/providers/config_provider.dart';
import 'package:sheet_music_ui/ui/screens/home/home_screen.dart';

final List _allAssets = [
  "assets/images/mascot/home-screen-logo.png",
  "assets/images/btn-images/note.png",
  "assets/images/level-preview/level-one-preview.png",
  "assets/images/level-preview/level-two-preview.png",
  "assets/images/level-preview/level-three-preview.png",
  "assets/images/level-preview/level-four-preview.png",
  "assets/images/style-preview/classical-preview.png",
  "assets/images/style-preview/anime-preview.png",
  "assets/images/backgrounds/blurred-empty-staves-heavy.png"
];

void main() async {
  final binding = WidgetsFlutterBinding.ensureInitialized();

  // precache assets
  binding.addPostFrameCallback((_) async {
    BuildContext? context = binding.rootElement;
    if(context != null)
      {
        for(int i = 0; i < _allAssets.length; i++)
        {
          final asset = _allAssets[i];
          precacheImage(AssetImage(asset), context);
        }
      }
  });

  // Load saved configuration data
  // We use providers to abstract the data
  final ConfigProvider configProvider = ConfigProvider();
  await configProvider.loadConfig();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => ConfigProvider(),
        ),
        ChangeNotifierProvider(
          create: (_) => FGBGProvider(),
        ),
      ],
      child: MainApp(),
    )
  );
}

class MainApp extends StatelessWidget {
  final FGBGProvider fgbgProvider = FGBGProvider();
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    return FGBGNotifier(
      onEvent: (event) {
        fgbgProvider.onFGBGChange(event);
      },
      child: MaterialApp(
        title: 'PianoSight',
        home: HomeScreen(),
      )
    );
  }
}
