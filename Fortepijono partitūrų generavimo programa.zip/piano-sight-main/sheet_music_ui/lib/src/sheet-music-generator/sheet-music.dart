import 'package:abc_dart/src/controllers/sheet_music_viewer_controller.dart';
import 'package:abc_dart/main.dart';
import 'package:flutter/material.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:sheet_music_ui/providers/config_provider.dart';
import 'package:sheet_music_ui/src/sheet-music-generator/sheet_music_controller.dart';

class SheetMusic extends StatelessWidget {
  final ConfigProvider generatorConfigProvider = ConfigProvider();
  late SheetMusicController sheetMusicController;
  
  SheetMusic({
    super.key,
  });

  // Function to generate sheet music when button is pressed
  void generateSheetMusic() {
    // Call the method to generate sheet music
    sheetMusicController.generateSheetMusic(generatorConfigProvider.config);
  }

  void stopSheetMusicPlayer() {
    sheetMusicController.stopSheetMusicPlayer();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // The WebViewApp widget integrated here with the callback
        Expanded(
          child: WebViewApp(
            onControllerCreated: (controller) {
              sheetMusicController = SheetMusicController(
                sheetMusicViewerController:  controller
              );  // Assign controller
            },
            onPageFinished: () {
              generateSheetMusic();
            }
          ),
        ),
      ],
    );
  }
}