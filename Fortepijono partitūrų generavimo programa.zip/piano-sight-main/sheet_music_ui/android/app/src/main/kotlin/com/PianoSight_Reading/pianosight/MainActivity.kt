package com.PianoSight_Reading.pianosight

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
