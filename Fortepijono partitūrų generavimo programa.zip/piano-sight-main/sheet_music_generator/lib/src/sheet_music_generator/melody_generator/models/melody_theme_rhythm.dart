import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';

class MelodyThemeRhythm {
  final List<NoteDuration> rhythm; // List of durations for the rhythm
  final List<List<NoteDuration>> variations = []; // List of variations for the rhythm

  MelodyThemeRhythm({
    required this.rhythm,
  });

  // Method to generate a variation of the rhythm
  List<NoteDuration> generateVariation() {
    Random random = Random();
    List<NoteDuration> variation = rhythm.map((noteDuration) {
      return random.nextBool() ? noteDuration : _modifyDurationRandomly(noteDuration);
    }).toList();
    variations.add(variation);

    return variation;
  }

  // Helper method to slightly modify a duration (for example, changing a quarter note to an eighth note)
  NoteDuration _modifyDurationRandomly(NoteDuration noteDuration, { int variationRange = 2 }) {
    // to be implemented
    return noteDuration;
  }
}
