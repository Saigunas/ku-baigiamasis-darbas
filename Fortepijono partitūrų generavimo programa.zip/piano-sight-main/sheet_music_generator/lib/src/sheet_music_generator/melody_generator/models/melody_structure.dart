
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_bar.dart';

class MelodyStructure {
  List<MelodyBar> bars = []; // Each bar will have its own structure

  void addBar(MelodyDirection direction, Feel feel, SectionType sectionType, bool shouldFollowMelody) {
    bars.add(MelodyBar(
      direction: direction,
      feel: feel,
      sectionType: sectionType,
      shouldFollowMelody: shouldFollowMelody,
    ));

    return;
  }
}