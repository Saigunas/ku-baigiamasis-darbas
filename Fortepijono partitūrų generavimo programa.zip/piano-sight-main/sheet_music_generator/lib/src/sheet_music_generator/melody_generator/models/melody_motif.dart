import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/melody_structure_data.dart';

class MelodyMotif {
  final MotifLength motifLength;
  final List<NoteDuration> rhythm;
  final List<List<String>> variations = [];
  final Random random;
  final List<NoteGroup> melody = [];


  MelodyMotif({
    required this.motifLength,
    required this.rhythm,
    Random? random,
  }) : random = random ?? Random();

/*
  // Method to apply slight variations to the motif
  List<String> generateVariation() {
    List<String> variation = melody.map((note) {
      return random.nextBool() ? shiftNoteRandomly(note) : note;
    }).toList();

    variations.add(variation);
    return variation;
  }
*/
  // Helper method to slightly modify a note
  String shiftNoteRandomly(String note, { int variationRange = 2 }) {
    int noteIndex = majorScaleNotes.indexOf(note);
    if (noteIndex == -1) return note;
    return majorScaleNotes[(noteIndex + random.nextInt(variationRange*2) - variationRange) % majorScaleNotes.length];
  }
}