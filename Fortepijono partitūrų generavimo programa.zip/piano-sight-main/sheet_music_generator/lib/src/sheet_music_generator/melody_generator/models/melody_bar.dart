
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/enums.dart';

class MelodyBar {
  final MelodyDirection direction;
  final Feel feel;
  final SectionType sectionType;
  final bool shouldFollowMelody;
  
  MelodyBar({
    required this.direction,
    required this.feel,
    required this.sectionType,
    required this.shouldFollowMelody,
  });
}