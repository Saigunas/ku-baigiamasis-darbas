
import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_theme_rhythm.dart';

class MelodyTheme {
  final List<NoteGroup> melody = [];
  final MelodyThemeRhythm themeRhythm;

  MelodyTheme({
    required this.themeRhythm,
  });
}