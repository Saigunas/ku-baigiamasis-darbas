import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/models/chord.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/melody_structure_data.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_bar.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_structure.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_theme.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_theme_rhythm.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/services/melody_rhythm_generator.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/utils/melody_helper.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class MelodyThemeGenerator {
  final Time time;
  final Random random; // Inject random for testability
  final List<String> melodyBase;
  final MelodyHelper _melodyHelper = MelodyHelper();
  final GeneratorConfig generatorConfig;

  late MelodyTheme theme;

  List<String> baseScale = [];
  List<String> contextScale = [];
  List<String> contextMelodyBase = [];

  MelodyThemeGenerator({
    required this.time,
    required this.melodyBase,
    required this.generatorConfig,
    Random? random,
  }) : random = random ?? Random();
  
  MelodyTheme initializeTheme() {
    MelodyThemeRhythm themeRhythm = _generateThemeRhythm();
    theme = MelodyTheme(themeRhythm: themeRhythm);
    baseScale = majorScaleNotes;
    return theme;
  }

  void generateMelodyForTheme(MelodyStructure melodyStructure, List<Chord> chords) {
    Map<int, List<NoteGroup>> noteGroupsByBar = _melodyHelper.groupNoteGroupsByBar(theme.melody);
    
    for(int bar in noteGroupsByBar.keys) {
      contextScale = baseScale;
      contextMelodyBase = melodyBase;

      List<NoteGroup> noteGroups = noteGroupsByBar[bar] ?? [];
      if(noteGroups.isEmpty) {
        throw Exception('Error: Current bar has no NoteGroups');
      }

      MelodyBar currentBar = melodyStructure.bars[bar];
      MelodyDirection melodyDirection = currentBar.direction;
      Feel feel = currentBar.feel;
      
      Chord contextChord = chords.firstWhere((chord) => chord.bar == bar);
      if(feel == Feel.release) {
        List<String> notes = contextChord.notes;
        String rootNote = notes.first;
        KeyType keyType = contextChord.keyType;
        List<String> pentatonicScale = _melodyHelper.getPentatonicScale(rootNote, keyType);
        contextScale = _melodyHelper.mapPentatonicToScale(contextScale, pentatonicScale);
        contextMelodyBase = _melodyHelper.mapPentatonicToScale(contextMelodyBase, pentatonicScale);
      } 

      switch(melodyDirection) {
        case MelodyDirection.ascending:
          _generateAscendingBar(noteGroups, currentBar);
          break;
        case MelodyDirection.descending:
          _generateDescendingBar(noteGroups, currentBar);
          break;
        case MelodyDirection.static:
          _generateStaticBar(noteGroups, currentBar);
          break;
      }
      
    }
  }
  

  void _generateAscendingBar(List<NoteGroup> noteGroups, MelodyBar bar) {

    // Ascend but with some variation (not strictly ascending)
    int variationRangeStart = -1;
    int variationRangeEnd = 3;

    int previousVariation = 0;
    int timesAscendedInARow = 0;

    for (int index = 0; index < noteGroups.length; index++) {
      NoteGroup noteGroup = noteGroups[index];
      if(index == 0) {
        _addPitchesForFirstNoteGroupOfBar(noteGroup, bar);
        continue;
      }

      // Ensure the melody follows the contour by modifying varation range start and end
      if(index != 1 && previousVariation <= 0) {
        variationRangeStart++;
      }
      if(timesAscendedInARow > 1) {
        variationRangeStart--;
      }

      final int baseNoteIndex = contextScale.indexOf(noteGroups[index - 1].pitches.first);
      if (baseNoteIndex == -1) {
        throw Exception('_generateAscendingBar: Invalid baseNote index for index of ${noteGroups[index - 1].pitches.first} in $contextScale');
      }

      int variationRange = variationRangeEnd - variationRangeStart;
      int variation = random.nextInt(variationRange) + variationRangeStart;

      timesAscendedInARow++;
      if(variation <= 0) {
        timesAscendedInARow = 0;
      }

      int nextNoteIndex = baseNoteIndex + variation;

      nextNoteIndex = nextNoteIndex.clamp(0, contextScale.length - 1); // Ensure within contextScale range
      noteGroup.pitches.add(contextScale[nextNoteIndex]);

      previousVariation = variation;
    }
  }

  void _generateDescendingBar(List<NoteGroup> noteGroups, MelodyBar bar) {

    // Ascend but with some variation (not strictly ascending)
    int variationRangeStart = -3;
    int variationRangeEnd = 1;

    int previousVariation = 0;
    int timesDescendedInARow = 0;

    for (int index = 0; index < noteGroups.length; index++) {
      NoteGroup noteGroup = noteGroups[index];
      if(index == 0) {
        _addPitchesForFirstNoteGroupOfBar(noteGroup, bar);
        continue;
      }

      // Ensure the melody follows the contour by modifying varation range start and end
      if(index != 1 && previousVariation >= 0) {
        variationRangeEnd--;
      }
      if(timesDescendedInARow > 1) {
        variationRangeEnd++;
      }

      final int baseNoteIndex = contextScale.indexOf(noteGroups[index - 1].pitches.first);
      if (baseNoteIndex == -1) {
        throw Exception('_generateDescendingBar: Invalid baseNote index for index of ${noteGroups[index - 1].pitches.first} in $contextScale');
      }

      int variationRange = variationRangeEnd - variationRangeStart;
      int variation = random.nextInt(variationRange) + variationRangeStart;

      timesDescendedInARow++;
      if(variation >= 0) {
        timesDescendedInARow = 0;
      }

      int nextNoteIndex = baseNoteIndex + variation;

      nextNoteIndex = nextNoteIndex.clamp(0, contextScale.length - 1); // Ensure within contextScale range
      noteGroup.pitches.add(contextScale[nextNoteIndex]);

      previousVariation = variation;
    }
  }

  void _generateStaticBar(List<NoteGroup> noteGroups, MelodyBar bar) {

    // Ascend but with some variation (not strictly ascending)
    int variationRangeStart = -2;
    int variationRangeEnd = 2;

    int previousVariation = 0;
    int timesAscendedInARow = 0;
    int timesDescendedInARow = 0;

    for (int index = 0; index < noteGroups.length; index++) {
      NoteGroup noteGroup = noteGroups[index];
      if(index == 0) {
        _addPitchesForFirstNoteGroupOfBar(noteGroup, bar);
        continue;
      }

      // Ensure the melody follows the contour by modifying varation range start and end
      if(previousVariation < 0) {
        variationRangeStart++;
        variationRangeEnd++;
      }
      if(previousVariation > 0) {
        variationRangeStart--;
        variationRangeEnd--;
      }

      final int baseNoteIndex = contextScale.indexOf(noteGroups[index - 1].pitches.first);
      if (baseNoteIndex == -1) {
        throw Exception('_generateStaticBar: Invalid baseNote index for index of ${noteGroups[index - 1].pitches.first} in $contextScale');
      }

      int variationRange = variationRangeEnd - variationRangeStart;
      int variation = random.nextInt(variationRange) + variationRangeStart;

      timesAscendedInARow++;
      if(variation < 0) {
        timesAscendedInARow = 0;
      }
      timesDescendedInARow++;
      if(variation > 0) {
        timesDescendedInARow = 0;
      }

      int nextNoteIndex = baseNoteIndex + variation;

      nextNoteIndex = nextNoteIndex.clamp(0, contextScale.length - 1); // Ensure within contextScale range
      noteGroup.pitches.add(contextScale[nextNoteIndex]);

      previousVariation = variation;
    }
  }

  void _addPitchesForFirstNoteGroupOfBar(NoteGroup noteGroup, MelodyBar bar) {
    Map<int, List<NoteGroup>> noteGroupsByBar = _melodyHelper.groupNoteGroupsByBar(theme.melody);

    final int previousBarIndex = noteGroupsByBar.keys.toList().indexOf(noteGroup.bar) - 1;
    if(previousBarIndex < 0 || !bar.shouldFollowMelody) {
      _melodyHelper.appendRandomPitchToNoteGroup(noteGroup, random, contextMelodyBase);
      return;
    }

    NoteGroup prevNoteGroup = noteGroupsByBar.values.toList()[previousBarIndex].last;

    int variationRangeStart = -3;
    int variationRangeEnd = 3;

    String prevNoteGroupFirstNote = prevNoteGroup.pitches.firstOrNull ?? ''; 
    if(prevNoteGroupFirstNote == '') {
      _melodyHelper.appendRandomPitchToNoteGroup(noteGroup, random, contextMelodyBase);
      return;
    }

    String normalizedPrevNote = _melodyHelper.findClosestNoteMatch(contextScale, prevNoteGroupFirstNote);

    final int baseNoteIndex = contextScale.indexOf(normalizedPrevNote);
    if (baseNoteIndex == -1) {
      throw Exception('_addPitchesForFirstNoteGroupOfBar: Invalid baseNote index for index of $normalizedPrevNote in $contextScale');
    }  

    // If the initial note index is at the edges of the allowed note range, adjust the variation accordingly.

    double closeToCeilingThreshold = 0.75;
    double closeToFloorThreshold = 1 - closeToCeilingThreshold;

    double howCloseToEdge = baseNoteIndex / contextScale.length;

    if(howCloseToEdge >= closeToCeilingThreshold) {
      variationRangeStart = -4;
      variationRangeEnd = -1;
    }
    if(howCloseToEdge <= closeToFloorThreshold) {
      variationRangeStart = 1;
      variationRangeEnd = 4;
    }

    int variationRange = variationRangeEnd - variationRangeStart;
    int variation = random.nextInt(variationRange) + variationRangeStart;

    int nextNoteIndex = baseNoteIndex + variation;

    nextNoteIndex = nextNoteIndex.clamp(0, contextScale.length - 1); // Ensure within contextScale range
    noteGroup.pitches.add(contextScale[nextNoteIndex]);
  }

  MelodyThemeRhythm _generateThemeRhythm() {
    MelodyRhythmGenerator rhythmGenerator = MelodyRhythmGenerator(
      generatorConfig: generatorConfig,
      time: time,
      random: random,
    );
    MelodyThemeRhythm themeRhythm = rhythmGenerator.generateRhythm();

    return themeRhythm;
  }
}
