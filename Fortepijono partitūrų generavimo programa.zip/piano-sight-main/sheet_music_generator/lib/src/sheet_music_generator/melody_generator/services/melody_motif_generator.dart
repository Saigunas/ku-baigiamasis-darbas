import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/models/chord.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/melody_structure_data.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_motif.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/utils/melody_helper.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class MelodyMotifGenerator {
  final Time time;
  final List<String> melodyBase;
  final Random random;
  final MelodyHelper _melodyHelper = MelodyHelper();
  final GeneratorConfig generatorConfig;

  List<String> contextMelodyBase = [];

  MelodyMotifGenerator({
    required this.time,
    required this.melodyBase,
    required this.generatorConfig,
    Random? random,
  }) : random = random ?? Random();

  MelodyMotif initializeMotif() {
    /// ONLY WORKS FOR ONE BAR LENGTH NOW
    MotifLength motifLength = MotifLength.oneBar;

    // Get rhythm template based on style, time signature, and motif motifLength
    List<NoteDuration> rhythm = _getRandomRhythmTemplate(
      style: generatorConfig.style,
      difficulty: generatorConfig.difficulty,
      time: time,
    );

    return MelodyMotif(
      motifLength: motifLength,
      rhythm: rhythm,
    );
  }

  void generateMelodyForMotif(MelodyMotif motif, List<Chord> chords) {
    List<NoteGroup> motifNoteGroupPitches = [];
    List<String> pentatonicScale = [];
    contextMelodyBase = melodyBase;

    Map<int, List<NoteGroup>> noteGroupsByBar = _melodyHelper.groupNoteGroupsByBar(motif.melody);
    for(int i = 0; i < noteGroupsByBar.length; i++) {
      int bar = noteGroupsByBar.keys.toList()[i];

      List<NoteGroup> noteGroups = noteGroupsByBar[bar] ?? [];
      if(noteGroups.isEmpty) {
        throw Exception('Error: Current bar has no NoteGroups');
      }

      // Adapt motif bar to context
      Chord contextChord = chords.firstWhere((chord) => chord.bar == bar);
      KeyType keyType = contextChord.keyType;
      String rootNote = contextChord.notes.first;

      pentatonicScale = _melodyHelper.getPentatonicScale(rootNote, keyType);
      contextMelodyBase = _melodyHelper.mapPentatonicToScale(contextMelodyBase, pentatonicScale);

      if(i == 0) {
        _generateBar(noteGroups);
        motifNoteGroupPitches = noteGroups;
        continue;
      }
      // For all other bars adjust the motif to match the chord context

      for(int noteGroupIndex = 0; noteGroupIndex < noteGroups.length; noteGroupIndex++) {
        List<String> pentatonicMotif = _melodyHelper.mapPentatonicToNoteList(motifNoteGroupPitches[noteGroupIndex].pitches, pentatonicScale);
        noteGroups[noteGroupIndex].pitches.addAll(pentatonicMotif);
      }
    }
  }

  void _generateBar(List<NoteGroup> noteGroups) {
    for(int i = 0; i < noteGroups.length; i++) {
      NoteGroup noteGroup = noteGroups[i];
      if(i == 0) {
        _melodyHelper.appendRandomPitchToNoteGroup(noteGroup, random, contextMelodyBase);
        continue;
      }
      // Take any note from the melody base
      String pitch = contextMelodyBase[random.nextInt(contextMelodyBase.length)];

      noteGroup.pitches.add(pitch);
    }
  }

  List<NoteDuration> _getRandomRhythmTemplate({
    required Style style,
    required Time time,
    required Difficulty difficulty,
  }) {

    // Get the available templates for the specified style and time
    Map<Time, List<Map<String, Object>>>? availableTemplatesForStyle = rhythmTemplates[style];
    List<Map<String, Object>>? availableTemplatesForTime = availableTemplatesForStyle?[time];

    if (availableTemplatesForTime == null || availableTemplatesForTime.isEmpty) {
      throw Exception('No motif chord patterns available for the style: $style and time: $time');
    }

    // Filter to find patterns that match the specified difficulty
    List<Map<String, dynamic>> templatesForDifficulty = availableTemplatesForTime.where((pattern) {
      return (pattern['difficulty'] as List<Difficulty>).contains(difficulty);
    }).toList();

    if (templatesForDifficulty.isEmpty) {
      throw Exception('No motif chord patterns available for the style: $style, time: $time with difficulty: $difficulty');
    }

    // choose random template from templatesForDifficulty.
    Random random = Random();
    int randomPatternIndex = random.nextInt(templatesForDifficulty.length);
    Map<String, dynamic> selectedPatternType = templatesForDifficulty[randomPatternIndex];

    Map<MotifLength, List<NoteDuration>> motifsByBarLength = selectedPatternType['MotifsByBarLength'];

    MotifLength motifLength = MotifLength.oneBar;
    List<NoteDuration> selectedMotifRhythm = motifsByBarLength[motifLength] ?? [];

    if (selectedMotifRhythm.isEmpty) {
      throw Exception('No motif rhythm templates found for style: $style, time signature: $time, motif length: $motifLength');
    }
    return selectedMotifRhythm;
  }
}
