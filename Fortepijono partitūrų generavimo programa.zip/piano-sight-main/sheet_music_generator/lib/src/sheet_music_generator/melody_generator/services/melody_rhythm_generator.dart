import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/melody_structure_data.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_theme_rhythm.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class MelodyRhythmGenerator {
  final Time time;
  final Random random; // Inject random for testability
  final GeneratorConfig generatorConfig;
  
  MelodyRhythmGenerator({
    required this.time,
    required this.generatorConfig,
    Random? random,
  }) : random = random ?? Random(); // Fallback to default random if not provided

  // Function to generate a rhythm
  MelodyThemeRhythm generateRhythm() {
    // Choose a random rhythm from the template
    List<NoteDuration> selectedRhythm = _getRandomRhythmTemplate(
      style: generatorConfig.style,
      time: time,
      difficulty: generatorConfig.difficulty,
    );

    return MelodyThemeRhythm(
      rhythm: selectedRhythm,
    );
  }

  List<NoteDuration> _getRandomRhythmTemplate({
    required Style style,
    required Time time,
    required Difficulty difficulty,
  }) {

    // Get the available templates for the specified style and time
    Map<Time, List<Map<String, List<Enum>>>>? availableTemplatesForStyle = melodyRhythmTemplates[style];
    List<Map<String, List<Enum>>>? availableTemplatesForTime = availableTemplatesForStyle?[time];

    if (availableTemplatesForTime == null || availableTemplatesForTime.isEmpty) {
      throw Exception('No theme chord patterns available for the style: $style and time: $time');
    }

    // Filter to find patterns that match the specified difficulty
    List<Map<String, List<Enum>>> templatesForDifficulty = availableTemplatesForTime.where((pattern) {
      // Safely filter the Enum list to include only elements of type Difficulty
      List<Difficulty> difficultyList = (pattern['difficulty'] ?? []).whereType<Difficulty>().toList();

      // Check if the filtered list contains the specific difficulty
      return difficultyList.contains(difficulty);
    }).toList();

    if (templatesForDifficulty.isEmpty) {
      throw Exception('No theme chord patterns available for the style: $style, time: $time with difficulty: $difficulty');
    }

    // choose random template from templatesForDifficulty.
    Random random = Random();
    int randomPatternIndex = random.nextInt(templatesForDifficulty.length);
    Map<String, List<Enum>> selectedPatternType = templatesForDifficulty[randomPatternIndex];

    List<Enum> themePattern = selectedPatternType['pattern'] ?? [];
    if (themePattern.isEmpty) {
      throw Exception('No theme rhythm templates found for style: $style, time signature: $time');
    }
    List<NoteDuration> noteDurations = themePattern.map((e) => e as NoteDuration).toList(); 
    return noteDurations;
  }
}
