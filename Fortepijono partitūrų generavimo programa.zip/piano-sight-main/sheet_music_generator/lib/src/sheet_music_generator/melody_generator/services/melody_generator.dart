import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/models/chord.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/services/sheet_music/services/sheet_music_service.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/melody_structure_data.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_bar.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_motif.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_structure.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_theme.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/services/melody_motif_generator.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/services/melody_structure_generator.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/services/melody_theme_generator.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';


class MelodyGenerator {
  final Time time;
  final int bars;
  final SheetMusicService sheetMusicService;
  final Random random;
  GeneratorConfig generatorConfig;

  late MelodyMotifGenerator melodyMotifGenerator;
  late MelodyThemeGenerator melodyThemeGenerator;
  late MelodyStructureGenerator structureGenerator;

  MelodyGenerator({
    this.time = Time.four_four,
    this.bars = 8, // Default to 8 bars
    required this.random,
    required this.sheetMusicService,
    required this.generatorConfig,
  })
  {
    List<String> melodyBase = _createMelodyBase(generatorConfig.style, majorScaleNotes, random);
    melodyMotifGenerator = MelodyMotifGenerator(
      generatorConfig: generatorConfig,
      time: time,
      random: random,
      melodyBase: melodyBase,
    );
    melodyThemeGenerator = MelodyThemeGenerator(
      time: time, 
      generatorConfig: generatorConfig,
      random: random,
      melodyBase: melodyBase,
    );
    structureGenerator = MelodyStructureGenerator();
  }

  void generateMelody(List<Chord> chords) {
    MelodyStructure melodyStructure = structureGenerator.createStructure(bars, generatorConfig.style, random);
    
    // initialize sections, then add noteGroups
    MelodyMotif motif = melodyMotifGenerator.initializeMotif();
    MelodyTheme theme = melodyThemeGenerator.initializeTheme();

    createNoteGroupsForSections(melodyStructure, motif, theme);

    melodyMotifGenerator.generateMelodyForMotif(motif, chords);
    melodyThemeGenerator.generateMelodyForTheme(melodyStructure, chords);

    _addSectionsToSheetMusic(motif, theme);
  }

  createNoteGroupsForSections(MelodyStructure melodyStructure, MelodyMotif motif, MelodyTheme theme) {
    for (int i = 0; i < bars; i++) {
      MelodyBar bar = melodyStructure.bars[i];

      // Convert the section into NoteGroups and add to the bar
      if (bar.sectionType == SectionType.motif) {
        for (int j = 0; j < motif.rhythm.length; j++) {
          motif.melody.add(
            NoteGroup(
              pitches: [],
              voiceLineId: 1, // Assuming a single melody line for now
              bar: i,
              duration: motif.rhythm[j],
            ),
          );
        }
      } else if (bar.sectionType == SectionType.theme) {
        for (int j = 0; j < theme.themeRhythm.rhythm.length; j++) {
          theme.melody.add(
            NoteGroup(
              pitches: [],
              voiceLineId: 1, // Assuming a single melody line for now
              bar: i,
              duration: theme.themeRhythm.rhythm[j],
            ),
          );
        }
      }
    }
  }

  // create a list of possible notes that the melody should start from
  List<String> _createMelodyBase(
    Style style,
    List<String> scaleNotes,
    Random random,
  ) {
    int range = melodyBaseConfig[style]!['range'] ?? 0;
    int offsetFromEdge = melodyBaseConfig[style]!['offsetFromEdge'] ?? 0;

    // Create a shortened scale, removing the edge notes
    List<String> shortenedScale =
      scaleNotes.sublist(offsetFromEdge, scaleNotes.length - offsetFromEdge);

    int possibilities = shortenedScale.length - range;
    
    if(possibilities <= 0) {
      return shortenedScale;
    }
    
    int melodyBaseIndex = random.nextInt(possibilities);

    List<String> melodyBase = shortenedScale.sublist(melodyBaseIndex, melodyBaseIndex + range);
    return melodyBase;
  }

  void _addSectionsToSheetMusic(MelodyMotif motif, MelodyTheme theme) {
    for(NoteGroup noteGroup in motif.melody) {
      sheetMusicService.addNoteGroupToSheetMusic(noteGroup);
    }
    for(NoteGroup noteGroup in theme.melody) {
      sheetMusicService.addNoteGroupToSheetMusic(noteGroup);
    }
  }


  // Helper function to calculate the starting beat of the new note in the bar
  /*
  double _calculateBeatForNewNoteInBar(MelodyBar bar, NoteDuration duration) {
    /*
    if (bar.noteGroups.isEmpty) {
      // If there are no notes in the bar, the new note starts at beat 0
      return 0.0;
    } else {
      // Find the last note in the bar and calculate its ending beat
      NoteGroup lastNote = bar.noteGroups.last;
      double lastNoteEndBeat = lastNote.beat + lastNote.duration.getDurationInBeats(time.beatUnit);

      // The new note starts right after the last note
      return lastNoteEndBeat;
    }
    */
    return 0;
  }
  */
}
