import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/melody_structure_data.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/models/melody_structure.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class MelodyStructureGenerator {

  createStructure(int bars, Style style, Random? random) {
    MelodyStructure melodyStructure = MelodyStructure();

    // Get the lists from the dictionaries
    List<List<MelodyDirection>> possibleDirections = melodyDirectionDictionary[style] ?? [];
    List<List<Feel>> possibleFeels = melodyFeelDictionary[style] ?? [];
    List<List<SectionType>> possibleSectionTypes = melodySectionTypesDictionary[style] ?? [];
    List<List<bool>> possibleBarMelodyFollowDefinitions = barMelodyFollowDefinitionDictionary[style] ?? [];


    if (possibleDirections.isEmpty || melodyFeelDictionary.isEmpty || possibleSectionTypes.isEmpty || possibleBarMelodyFollowDefinitions.isEmpty) {
      throw Exception('No melody data available for style: $style');
    }

    // Create a random generator
    random = random ?? Random();

    List<MelodyDirection> directions = possibleDirections[random.nextInt(possibleDirections.length)];
    List<Feel> feels = possibleFeels[random.nextInt(possibleFeels.length)];
    List<SectionType> sectionTypes = possibleSectionTypes[random.nextInt(possibleSectionTypes.length)];
    List<bool> barMelodyFollowDefinition = possibleBarMelodyFollowDefinitions[random.nextInt(possibleBarMelodyFollowDefinitions.length)];

    bool isResetPending = false;
    // Generate the structure for the specified number of bars
    for (int i = 0; i < bars; i++) {
      // Choose a random direction, feel, and section type
      MelodyDirection direction = directions[i];
      Feel feel = feels[i];
      SectionType sectionType = sectionTypes[i];
      bool shouldFollowMelody = barMelodyFollowDefinition[i];

      // theme does not follow motif melodically, so it should be aware of the reset
      if(shouldFollowMelody == true && sectionType == SectionType.motif) {
        isResetPending = true;
      }
      if(isResetPending == true && sectionType == SectionType.theme) {
        shouldFollowMelody = false;
        isResetPending = false;
      }


      // Add the bar to the melody structure
      melodyStructure.addBar(direction, feel, sectionType, shouldFollowMelody);
    }


    return melodyStructure; // Return the complete melody structure
  }

}
