
import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/data/enums.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

const Map<Style, List<List<MelodyDirection>>> melodyDirectionDictionary = {
  Style.classical: [
    [
      MelodyDirection.ascending, MelodyDirection.static, MelodyDirection.descending, MelodyDirection.static,
      MelodyDirection.ascending, MelodyDirection.static, MelodyDirection.descending, MelodyDirection.static, // Standard alternation
    ],
    [
      MelodyDirection.ascending, MelodyDirection.ascending, MelodyDirection.descending, MelodyDirection.static,
      MelodyDirection.static, MelodyDirection.ascending, MelodyDirection.descending, MelodyDirection.static, // Ascending focus with contrast
    ],
    [
      MelodyDirection.static, MelodyDirection.static, MelodyDirection.ascending, MelodyDirection.descending,
      MelodyDirection.static, MelodyDirection.static, MelodyDirection.ascending, MelodyDirection.descending, // Static-dominant variation
    ],
  ],
    
  Style.anime: [
    [
      MelodyDirection.ascending, MelodyDirection.static, MelodyDirection.descending, MelodyDirection.static,
      MelodyDirection.ascending, MelodyDirection.ascending, MelodyDirection.ascending, MelodyDirection.static, // Building momentum
    ],
    [
      MelodyDirection.static, MelodyDirection.ascending, MelodyDirection.static, MelodyDirection.descending,
      MelodyDirection.ascending, MelodyDirection.ascending, MelodyDirection.descending, MelodyDirection.static, // Balanced alternation
    ],
    [
      MelodyDirection.ascending, MelodyDirection.ascending, MelodyDirection.static, MelodyDirection.static,
      MelodyDirection.descending, MelodyDirection.descending, MelodyDirection.ascending, MelodyDirection.static, // Dramatic shifts
    ],
  ],                    
};

const barMelodyFollowDefinitionDictionary = {
  Style.classical: [
    [
      true, true, true, true,
      true, true, true, true
    ],
    [
      true, true, true, true,
      false, true, true, true
    ],
  ],
  Style.anime: [
    [
      true, true, true, true,
      true, true, true, true
    ],
    [
      true, true, true, true,
      false, true, true, true
    ],
  ],
};

const Map<Style, List<List<Feel>>> melodyFeelDictionary = {
  Style.classical: [
    [
      Feel.release, Feel.release, Feel.release, Feel.release,
      Feel.release, Feel.release, Feel.release, Feel.release,
    ],
    [
      Feel.release, Feel.release, Feel.release, Feel.release,
      Feel.release, Feel.release, Feel.tension, Feel.release,
    ],
  ],           
  Style.anime: [
    [
      Feel.release, Feel.release, Feel.release, Feel.release,
      Feel.release, Feel.release, Feel.release, Feel.release,
    ],
    [
      Feel.release, Feel.release, Feel.release, Feel.release,
      Feel.release, Feel.release, Feel.tension, Feel.release,
    ],
  ],                             
};

const Map<Style, List<List<SectionType>>> melodySectionTypesDictionary = {
  Style.classical: [
    [
      SectionType.motif, SectionType.theme, SectionType.theme, SectionType.motif,
      SectionType.motif, SectionType.theme, SectionType.theme, SectionType.motif, // Standard alternation
    ],
    [
      SectionType.theme, SectionType.motif, SectionType.theme, SectionType.theme,
      SectionType.motif, SectionType.theme, SectionType.motif, SectionType.theme, // Theme-heavy variation
    ],
    [
      SectionType.motif, SectionType.motif, SectionType.theme, SectionType.theme,
      SectionType.motif, SectionType.motif, SectionType.theme, SectionType.theme, // Motif-focused variation
    ],
  ],        
  Style.anime: [
    [
      SectionType.theme, SectionType.theme, SectionType.theme, SectionType.motif,
      SectionType.theme, SectionType.theme, SectionType.theme, SectionType.motif, // Strong thematic development
    ],
    [
      SectionType.theme, SectionType.motif, SectionType.theme, SectionType.motif,
      SectionType.theme, SectionType.theme, SectionType.theme, SectionType.motif, // Interspersed motifs for contrast
    ],
    [
      SectionType.theme, SectionType.theme, SectionType.motif, SectionType.theme,
      SectionType.theme, SectionType.motif, SectionType.theme, SectionType.theme, // Alternating structure
    ],
  ],                         
};

// Dictionary for rhythm templates categorized by Style, Time, and MotifLength
const Map<Style, Map<Time, List<Map<String, Object>>>> rhythmTemplates = {
  Style.classical: {
    Time.four_four: [
      {
        'difficulty': [Difficulty.one,],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.whole],
        }
      },
      {
        'difficulty': [Difficulty.one,Difficulty.two],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.half, NoteDuration.half],
        }
      },

// Difficulty 2

      {
        'difficulty': [Difficulty.two],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.half], // Strong rhythmic base
        }
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.half, NoteDuration.quarter, NoteDuration.quarter], // Smooth and flowing
        }
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter], // Pure rhythm-focused simplicity
        }
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.half, NoteDuration.quarter], // Minimalist classical feel
        }
      },


// Difficulty 3
      {
        'difficulty': [Difficulty.three],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.half], // classical syncopation
        }
      },
      {
        'difficulty': [Difficulty.three],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.half],
        }
      },
      {
        'difficulty': [Difficulty.three],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.half, NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth], // Driving rhythmic energy
        }
      },
      {
        'difficulty': [Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.eighth, NoteDuration.eighth, NoteDuration.half, NoteDuration.quarter], // Bright with a strong ending
        }
      },
      {
        'difficulty': [Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter], // Gradual build
        }
      },
      {
        'difficulty': [Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter], // Balanced repetition
        }
      },

// Difficulty 4
      {
        'difficulty': [Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.eighth, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter], // Rhythmic complexity
        }
      },
      {
        'difficulty': [Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter], // Alternating focus
        }
      },
      {
        'difficulty': [Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter, NoteDuration.eighth], // Groove with a twist
        }
      },
      {
        'difficulty': [Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter], // Full rhythmic exploration
        }
      },
    ],
  },
  Style.anime: {
    Time.four_four: [
      {
        'difficulty': [Difficulty.one],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.whole], // Simple and flowing for introductory anime themes
        }
      },
      {
        'difficulty': [Difficulty.one, Difficulty.two],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.half, NoteDuration.half], // Balanced and steady rhythm
        }
      },

// Difficulty two

      {
        'difficulty': [Difficulty.two],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.half], // Building energy, common in anime intros
        }
      },
      {
        'difficulty': [Difficulty.two],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.half], // Strong rhythmic base
        }
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.halfdotted, NoteDuration.quarter], // dotted rhythm
        }
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarterdotted, NoteDuration.eighth, NoteDuration.half], // Dramatic flair with syncopation
        }
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter], // Simple yet versatile
        }
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.half, NoteDuration.quarter], // Minimalist yet melodic
        }
      },

// Difficulty three 

      {
        'difficulty': [Difficulty.three],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.half], // Syncopated and dynamic
        }
      },
      {
        'difficulty': [Difficulty.three],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarterdotted, NoteDuration.eighth], // Complex syncopation with dotted emphasis
        }
      },
      {
        'difficulty': [Difficulty.three],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.halfdotted, NoteDuration.eighth, NoteDuration.eighth], // Dramatic tension
        }
      },
      {
        'difficulty': [Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter], // Gradual build with flow
        }
      },
      {
        'difficulty': [Difficulty.three, Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter], // Balanced repetition
        }
      },

// Difficulty four 

      {
        'difficulty': [Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.eighth, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter], // Rapid and engaging
        }
      },
      {
        'difficulty': [Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter], // Syncopated and vibrant
        }
      },
      {
        'difficulty': [Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarterdotted, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter], // Emotional and intricate
        }
      },
      {
        'difficulty': [Difficulty.four],
        'MotifsByBarLength': {
          MotifLength.oneBar: [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarterdotted, NoteDuration.eighth], // Emotional intensity with rhythmic focus
        }
      },
    ],
  },
};

const Map<Style, Map<Time, List<Map<String, List<Enum>>>>> melodyRhythmTemplates = {
  Style.classical: {
    Time.four_four: [
      {
        'difficulty': [Difficulty.one],
        'pattern': [NoteDuration.whole], // Slow and sustained
      },
      {
        'difficulty': [Difficulty.one],
        'pattern': [NoteDuration.half, NoteDuration.half], // Simple and steady
      },
      {
        'difficulty': [Difficulty.one, Difficulty.two],
        'pattern': [NoteDuration.half, NoteDuration.quarter, NoteDuration.quarter], // Balanced and flowing
      },
      {
        'difficulty': [Difficulty.one, Difficulty.two, Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.half], // Foundation rhythm
      },

// Difficulty two

      {
        'difficulty': [Difficulty.two],
        'pattern': [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter], // Rhythmic consistency
      },
      {
        'difficulty': [Difficulty.two],
        'pattern': [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.half], // Light syncopation
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.half, NoteDuration.quarterdotted, NoteDuration.eighth], // Touch of dotted rhythm
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.quarterdotted, NoteDuration.eighth, NoteDuration.half], // Balanced and dynamic
      },

// Difficulty three
      {
        'difficulty': [Difficulty.three],
        'pattern': [NoteDuration.quarterdotted, NoteDuration.quarterdotted, NoteDuration.quarter],
      },
      {
        'difficulty': [Difficulty.three],
        'pattern': [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter], // Balanced repetition
      },
      {
        'difficulty': [Difficulty.three],
        'pattern': [NoteDuration.quarterdotted, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter], // Complex dotted rhythm
      },
      {
        'difficulty': [Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.halfdotted, NoteDuration.eighth, NoteDuration.eighth], // Sustained but with syncopation
      },

// Difficulty four

      {
        'difficulty': [Difficulty.four],
        'pattern': [NoteDuration.eighth, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter], // Rapid momentum
      },
      {
        'difficulty': [Difficulty.four],
        'pattern': [NoteDuration.eighth, NoteDuration.quarterdotted, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.eighth], // Advanced rhythmic diversity
      },
      {
        'difficulty': [Difficulty.four],
        'pattern': [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarterdotted, NoteDuration.eighth], // Complex and flowing
      },

    ],
  },
  Style.anime: {
    Time.four_four: [
      {
        'difficulty': [Difficulty.one],
        'pattern': [NoteDuration.whole], // Long, sustained tones for emotional intros
      },
      {
        'difficulty': [Difficulty.one],
        'pattern': [NoteDuration.half, NoteDuration.half], // Calm and steady flow
      },
      {
        'difficulty': [Difficulty.one, Difficulty.two],
        'pattern': [NoteDuration.half, NoteDuration.quarter, NoteDuration.quarter], // Gentle and balanced
      },
      {
        'difficulty': [Difficulty.one, Difficulty.two, Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.half], // Foundational rhythm
      },

// Difficulty two

      {
        'difficulty': [Difficulty.two],
        'pattern': [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter, NoteDuration.quarter], // Simple but versatile
      },
      {
        'difficulty': [Difficulty.two],
        'pattern': [NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.half], // Bright and melodic
      },
      {
        'difficulty': [Difficulty.two],
        'pattern': [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.half], // Light syncopation with emotional pull
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.half, NoteDuration.quarterdotted, NoteDuration.eighth], // Expressive with a dramatic pause
      },
      {
        'difficulty': [Difficulty.two, Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.quarterdotted, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.quarter], // Balanced and dynamic
      },


// Difficulty three

      {
        'difficulty': [Difficulty.three],
        'pattern': [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.half], // Syncopated with an emotive conclusion
      },
      {
        'difficulty': [Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.quarter, NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter], // Balanced resolution
      },
      {
        'difficulty': [Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.quarterdotted, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarter], // Expressive dotted rhythm
      },
      {
        'difficulty': [Difficulty.three, Difficulty.four],
        'pattern': [NoteDuration.halfdotted, NoteDuration.eighth, NoteDuration.eighth], // Long note with syncopation
      },

// Difficulty four

      {
        'difficulty': [Difficulty.four],
        'pattern': [NoteDuration.eighth, NoteDuration.quarterdotted, NoteDuration.eighth, NoteDuration.quarter, NoteDuration.eighth], // Rhythmic diversity with emotional flow
      },
      {
        'difficulty': [Difficulty.four],
        'pattern': [NoteDuration.quarter, NoteDuration.eighth, NoteDuration.eighth, NoteDuration.quarterdotted, NoteDuration.eighth], // Complex and expressive
      },
    ],
  }
};


final List<String> majorScaleNotes = [
  'F,', 'G,', 'A,', 'B,', 'C', 'D', 'E', 'F', 'G', 'A', 'B', "C'", "D'", "E'", "F'", "G'"
];

final Map<Style, Map<String, int>> melodyBaseConfig = {
  Style.classical: {
    'range': 6,
    'offsetFromEdge': 4,
  },
  Style.anime: {
    'range': 3,
    'offsetFromEdge': 4,
  },
};

