enum MelodyDirection {
  ascending,
  descending,
  static,
}

enum Feel {
  tension,
  release,
  static,
}

enum SectionType {
  theme,
  motif,
}

enum MotifLength {
  oneBar,
  twoBars,
}