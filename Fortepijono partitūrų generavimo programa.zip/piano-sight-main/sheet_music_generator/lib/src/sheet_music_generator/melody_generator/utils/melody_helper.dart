import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/core/data/data.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class MelodyHelper {

  Map<int, List<NoteGroup>> groupNoteGroupsByBar(List<NoteGroup> noteGroups) {
    Map<int, List<NoteGroup>> groupedByBar = {};

    for (NoteGroup noteGroup in noteGroups) {
      int bar = noteGroup.bar;

      if (!groupedByBar.containsKey(bar)) {
        groupedByBar[bar] = [];
      }

      groupedByBar[bar]!.add(noteGroup);
    }

    return groupedByBar;
  }

  List<String> mapPentatonicToNoteList(final List<String> notes, final List<String> pentatonicScale) {
    // List to hold the updated scale notes after applying pentatonic modifiers
    List<String> mappedNotes = [];

    // For each pitch in the note group, adapt it to the closest pentatonic pitch
    for (int i = 0; i < notes.length; i++) {
      String currentNote = notes[i];

      List<String> expandedNote = _expandNote(currentNote);

      String modifier = expandedNote[0];
      String pitch = expandedNote[1];
      String octave = expandedNote[2];

      // Apply the pentatonic scale modifier to the current pitch
      String modifiedPitch = _applyPentatonicScaleModifierToPitch(pitch, pentatonicScale);

      if (modifiedPitch.isEmpty) {
        String closestMatch = findClosestNoteMatch(pentatonicScale, currentNote);
        mappedNotes.add(closestMatch);
        continue;
      }
      mappedNotes.add(modifiedPitch + octave);
    }

    return mappedNotes;
  }

  void appendRandomPitchToNoteGroup(NoteGroup noteGroup, Random random, List<String> scale) {
      int baseNoteIndex = random.nextInt(scale.length);
      noteGroup.pitches.add(scale[baseNoteIndex]);
      return;
  }

  List<String> getPentatonicScale(String pitch, KeyType quality) {
    // Chromatic scales
    List<String> chromaticScaleSharps = [
      'C',
      '^C',
      'D',
      '^D',
      'E',
      'F',
      '^F',
      'G',
      '^G',
      'A',
      '^A',
      'B'
    ];

    List<String> chromaticScaleFlats = [
      'C',
      '_D',
      'D',
      '_E',
      'E',
      'F',
      '_G',
      'G',
      '_A',
      'A',
      '_B',
      'B'
    ];

    // Find if pitch uses flat or major chromatic scale
    List<String> majorFlats = ['F', '_C', '_D', '_E', '_F', '_G', '_A', '_B'];

    List<String> majorSharps = ['C', 'G', 'D', 'A', 'E', 'B', '^C', '^D', '^E', '^F', '^G', '^A', '^B'];

    List<String> minorFlats = ['A', 'D', 'G', 'C', 'F', '_C', '_D', '_E', '_F', '_G', '_A', '_B'];

    List<String> minorSharps = ['E', 'B', '^C', '^D', '^E', '^F', '^G', '^A', '^B'];

    // Find the index of the starting pitch
    pitch = pitch.toUpperCase(); // Normalize the pitch case

    List<String> chromaticScale = [];


      if (quality == KeyType.major) {
        if (majorFlats.contains(pitch)) {
          chromaticScale = chromaticScaleFlats;
        }
        if (majorSharps.contains(pitch)) {
          chromaticScale = chromaticScaleSharps;
        }
      }
      if (quality == KeyType.minor) {
        if (minorFlats.contains(pitch)) {
          chromaticScale = chromaticScaleFlats;
        }
        if (minorSharps.contains(pitch)) {
          chromaticScale = chromaticScaleSharps;
        }
      }

    
    int startIndex = chromaticScale.indexOf(pitch);

    if (startIndex == -1) {
      throw ArgumentError('Invalid pitch: $pitch');
    }

    // Intervals for major and minor pentatonic scales
    List<int> majorPentatonicIntervals = [2, 2, 3, 2, 3]; // W-W-m3-W-m3
    List<int> minorPentatonicIntervals = [3, 2, 2, 3, 2]; // m3-W-W-m3-W

    List<int> intervals = quality == KeyType.major
        ? majorPentatonicIntervals
        : minorPentatonicIntervals;

    List<String> scale = [];
    int currentIndex = startIndex;

    for (int interval in intervals) {
      scale.add(chromaticScale[currentIndex % chromaticScale.length]);
      currentIndex += interval;
    }

    return scale;
  }
    
  List<String> mapPentatonicToScale(List<String> majorScale, List<String> pentatonicScale) {
    // List to hold the updated scale notes after applying pentatonic modifiers
    List<String> updatedScale = [];

    // Iterate through each note in the major scale
    for (int i = 0; i < majorScale.length; i++) {
      String currentMajorNote = majorScale[i];

      List<String> expandedNote = _expandNote(currentMajorNote);

      String modifier = expandedNote[0];
      String pitch = expandedNote[1];
      String octave = expandedNote[2];

      // Apply the pentatonic scale modifier to the current pitch
      String modifiedPitch = _applyPentatonicScaleModifierToPitch(pitch, pentatonicScale);
      if (modifiedPitch.isNotEmpty) {
        // If the pitch was modified, add it to the updated scale with its octave
        updatedScale.add(modifiedPitch + octave);
      }
    }
    
    return updatedScale;
  }

  List<String> _expandNote(String note) {
    // Regular expression to capture the modifier, pitch, and octave of the note
    RegExp regExp = RegExp("([_^]?)([A-Za-z])([,'']?)");
    Iterable<RegExpMatch> matches = regExp.allMatches(note);

    // Extract the modifier, pitch, and octave from the matches
    String modifier = matches.isNotEmpty ? matches.first[1] ?? '' : '';
    String pitch = matches.isNotEmpty ? matches.first[2] ?? '' : '';
    String octave = matches.isNotEmpty ? matches.first[3] ?? '' : '';

    List<String> expandedNote = [modifier, pitch, octave];

    return expandedNote;
  }

  String _applyPentatonicScaleModifierToPitch(String pitchToModify, List<String> pentatonicScale) {
    // Iterate through each note in the pentatonic scale
    for (int i = 0; i < pentatonicScale.length; i++) {
      // Extract the modifier and note
      String currentPentNote = pentatonicScale[i];
      String modifier = '';

      // Check if the first character is a modifier
      if (currentPentNote.startsWith('_') || currentPentNote.startsWith('^')) {
        modifier = currentPentNote[0]; // Assign the modifier
        currentPentNote = currentPentNote.substring(1); // Remove the modifier to get the note
      }

      // If the current pentatonic note matches the pitch to modify, return the modified note
      if (currentPentNote == pitchToModify) {
        return modifier + currentPentNote; // Prepend the modifier to the pitch
      }
    }
    
    return ''; // Return an empty string if no match is found
  }

  String findClosestNoteMatch(List<String> scaleToExplore, String noteToMatch) {
    if (scaleToExplore.contains(noteToMatch)) {
      return noteToMatch;
    }

    List<String> expandedNote = _expandNote(noteToMatch);

    String modifier = expandedNote[0];
    String pitch = expandedNote[1];
    String octave = expandedNote[2];

    noteToMatch = modifier + pitch;

    // Get a list of notes ordered by closest by pitch
    List<String> closestOctaveNotes = _orderListByClosestFrom(octaveNotes, noteToMatch);
    String match = '';
    for (int i = 0; i < closestOctaveNotes.length; i++) {
      String possibleMatch = closestOctaveNotes[i] + octave;
      if (scaleToExplore.contains(possibleMatch)) {
        match = possibleMatch;
        return match;
      }
    }

    if (match == '') {
      throw Exception('Match not found for $noteToMatch');
    }
    return match;
  }


  List<String> _orderListByClosestFrom(List<List<String>> stringsToSearch, String stringToSearch) {
    // Find the index of the list that contains the search letter
    int foundIndex = -1;
    for (int i = 0; i < stringsToSearch.length; i++) {
      if (stringsToSearch[i].contains(stringToSearch)) {
        foundIndex = i;
        break;
      }
    }

    // If letter is not found, return an empty list
    if (foundIndex == -1) {
      return [];
    }

    // Start building the new reordered list
    List<String> result = [];

    // Add the found list first
    result.addAll(stringsToSearch[foundIndex]);
    
    // Expand lists alternating left and right
    int left = foundIndex - 1;
    int right = foundIndex + 1;
    bool toggle = true;

    while (left >= 0 || right < stringsToSearch.length) {
      if (toggle && left >= 0) {
        result.addAll(stringsToSearch[left]);
        left--;
      } else if (!toggle && right < stringsToSearch.length) {
        result.addAll(stringsToSearch[right]);
        right++;
      }
      toggle = !toggle;      
    }

    return result;
  }
}