import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';

class SheetHelper {
  
  Map<String, num> getNextNoteGroupStart({
    required int currentBar, 
    required double currentBeat, 
    required NoteDuration duration, 
    required int beatsPerBar,  // Numerator of the time signature (e.g., 6 in 6/8)
    required int beatUnit       // Denominator of the time signature (e.g., 8 in 6/8)
  }) {
    // Convert the note duration into the number of beats it occupies based on the time signature
    double noteDurationInBeats = duration.getDurationInBeats(beatUnit);

    // Calculate the new beat position within the current bar
    double nextBeat = currentBeat + noteDurationInBeats;

    // If the next beat overflows the current bar, handle the overflow
    if (nextBeat >= beatsPerBar) {
      int additionalBars = nextBeat ~/ beatsPerBar;
      double newBeatInBar = nextBeat % beatsPerBar;

      return {
        'bar': currentBar + additionalBars,
        'beat': newBeatInBar
      };
    }

    return {
      'bar': currentBar,
      'beat': nextBeat
    };
  }

  static int getStepsToNote(String note) {
    final Map<int, Map<int, String>> stepsToNotes = {
      0: {0: 'C', 1: '^B'},
      1: {1: '^C', -1: '_D'},
      2: {0: 'D'},
      3: {1: '^D', -1: '_E'},
      4: {0: 'E', -1: '_F'},
      5: {0: 'F', 1: '^E'},
      6: {1: '^F', -1: '_G'},
      7: {0: 'G'},
      8: {1: '^G', -1: '_A'},
      9: {0: 'A'},
      10: {1: '^A', -1: '_B'},
      11: {0: 'B', -1: '_C'},
    };

    for (var step in stepsToNotes.keys) {
      for (var modifier in stepsToNotes[step]!.keys) {
        if (stepsToNotes[step]![modifier] == note) {
          return step;
        }
      }
    }

    return 0;
  }
}