
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

final Map<Difficulty, List<String>> transpositionDictionary = {
  // https://www.riam.ie/riam-exams/exam-supports/online-exam-resources/scales-arpeggios-for-piano-exams-grades-elementary
  // Contrary motion
  // Starting from Primary as difficulty one
  Difficulty.one: [
    'C', 'G'
  ],
  Difficulty.two: [
    'C', 'G', 'D'
  ],
  Difficulty.three: [
    'C', 'G', 'D', 'A', 'E'
  ],
  Difficulty.four: [
    'C', 'G', 'D', 'A', 'E', 'B', 'F'
  ],
};