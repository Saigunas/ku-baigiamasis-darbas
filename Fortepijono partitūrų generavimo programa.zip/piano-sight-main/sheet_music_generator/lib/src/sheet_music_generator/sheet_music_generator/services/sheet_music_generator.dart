import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/models/chord.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/services/chords_generator.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/services/sheet_music/services/sheet_music_service.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/services/melody_generator.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/sheet_music_generator/data/transposition_dictionary.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/sheet_music_generator/utils/sheet_helper.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class SheetMusicGenerator {
  SheetMusicConfig sheetMusicConfig;
  GeneratorConfig generatorConfig;
  late SheetMusicService sheetMusic;
  late ChordsGenerator chordsGenerator;
  late MelodyGenerator melodyGenerator;

  SheetMusicGenerator({
    required this.sheetMusicConfig,
    required this.generatorConfig,
  }) {
    sheetMusic = SheetMusicService(sheetMusicConfig: sheetMusicConfig);
    chordsGenerator = ChordsGenerator(generatorConfig: generatorConfig, sheetMusicConfig: sheetMusicConfig, sheetMusic: sheetMusic);
    melodyGenerator = MelodyGenerator(generatorConfig: generatorConfig, sheetMusicService: sheetMusic, random: Random());
  }

  String generateSheetMusic() {
    sheetMusic.reset();
    List<Chord> chords = chordsGenerator.generateChords();
    melodyGenerator.generateMelody(chords);
    return sheetMusic.abcString;
  }

  int getTransposeStep() {
    final random = Random();
    List<String> possibleKeys = transpositionDictionary[generatorConfig.difficulty] ?? [];
    if (possibleKeys.isEmpty) {
      throw Exception('No possibleKeys available for the difficulty: ${generatorConfig.difficulty}');
    }
    String selectedKey = possibleKeys[random.nextInt(possibleKeys.length)];
    return SheetHelper.getStepsToNote(selectedKey);
  }
}
