
import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';

class NoteGroup {
  final List<String> pitches;
  final bool accent;
  final Articulation articulation;
  final NoteDuration duration;
  final int voiceLineId;
  final int bar;

  NoteGroup({
    required this.pitches,
    required this.voiceLineId,
    required this.bar,
    this.accent = false,
    this.articulation = Articulation.none,
    required this.duration,
  });

  String toAbcString() {
    String notesAbcString = '[';
    for (String pitch in pitches) {
      String duration = this.duration.abcDuration;
      notesAbcString +=  pitch + duration;
    }
    notesAbcString += ']';
    return notesAbcString;
  }
}
