import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';

class Bar {
  final List<NoteGroup> noteGroups = [];

  Bar();

  // Add note to the bar
  void addNoteGroup(NoteGroup noteGroup) {
    noteGroups.add(noteGroup);
  }

  // Convert the Bar to ABC format
  String toABCString() {
    String abcString = '${noteGroups.map((noteGroup) => noteGroup.toAbcString()).join(" ")}';
    return abcString;
  }
}