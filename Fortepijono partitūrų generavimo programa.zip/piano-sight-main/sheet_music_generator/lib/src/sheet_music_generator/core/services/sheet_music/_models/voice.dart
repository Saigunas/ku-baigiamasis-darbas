
import 'package:sheet_music_generator/src/sheet_music_generator/core/services/sheet_music/_models/bar.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class Voice {
  final Clef clef;
  final List<Bar> bars = [];
  final int id;

  Voice({
    required this.clef,
    required this.id
  });

  // Add a bar to the voice
  void addBar(Bar bar) {
    bars.add(bar);
  }

  // Convert the voice to ABC format
  String toABCString(int barsPerLine) {
    String clefString = "V:$id clef=${clef.name}";

    // Initialize an empty list to store each line
    List<String> lines = [];

    // Iterate through bars, group them into lines based on barsPerLine
    for (int i = 0; i < bars.length; i += barsPerLine) {
      List<Bar> currentLineBars = bars.sublist(i, i + barsPerLine > bars.length ? bars.length : i + barsPerLine);
      String barLine = currentLineBars.map((bar) => bar.toABCString()).join(" | ");
      barLine += '|';
      lines.add(barLine);
    }

    String result = lines.join("\n");

    return "$clefString\n$result";
  }
}
