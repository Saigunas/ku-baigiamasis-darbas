

import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/services/sheet_music/_models/bar.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/services/sheet_music/_models/sheet_music.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/services/sheet_music/_models/voice.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class SheetMusicService {
  String _abcString = '';
  SheetMusicConfig sheetMusicConfig;
  SheetMusic sheetMusic = SheetMusic();

  SheetMusicService({
    required this.sheetMusicConfig,
  }) {
    _initializeSheetMusic();
  }

  String get abcString {
    if(_abcString == '') {
      _buildAbcString();
    }

    return _abcString;
  }

  String _createStavesOption() {
    String staves = '';
    // if more than one clef
    // for each clef create a staff
    // e.g. '%%staves {1 2}
    if(sheetMusicConfig.clefs.length > 1) {
      staves = '%%staves ';
      staves += '{';
      for(int clefIndex = 0; clefIndex < sheetMusicConfig.clefs.length; clefIndex++) {
        staves += (clefIndex + 1).toString();
        if(clefIndex + 1 < sheetMusicConfig.clefs.length) {
          staves += ' ';
        }
      }
      staves += '}';
    }

    return staves;
  }

  void reset() {
    _abcString = '';
    sheetMusic = SheetMusic();
    _initializeSheetMusic();
  }

  void _initializeSheetMusic() {
    for(int i = 0; i < sheetMusicConfig.clefs.length; i++) {
      Voice voice = Voice(clef: sheetMusicConfig.clefs[i], id: i + 1);
      for(int j = 0; j < sheetMusicConfig.bars.value; j++) {
        voice.addBar(Bar());
      }
      sheetMusic.addVoice(voice);
    }
  }

  void _buildAbcString() {
    _abcString = '';
    String keyOption = 'K: C';
    String stavesOption = _createStavesOption();
    String voiceLines = sheetMusic.toABCString(sheetMusicConfig.barsPerLine);

    _abcString += '$keyOption\n';
    _abcString += '$stavesOption\n';
    _abcString += '$voiceLines\n';
  }


  void addNoteGroupToSheetMusic(NoteGroup noteGroup) {
    Bar bar = _findBar(noteGroup);
    bar.addNoteGroup(noteGroup);
  }

  Bar _findBar(NoteGroup noteGroup) {
    final voice = sheetMusic.voices.firstWhere(
      (voice) => voice.id == noteGroup.voiceLineId,
      orElse: () => throw Exception('Voice: ${noteGroup.voiceLineId} not found'),
    );

    if (noteGroup.bar >= voice.bars.length) {
      throw Exception('Bar: ${noteGroup.bar} not found');
    }

    return voice.bars[noteGroup.bar];
  }
}
