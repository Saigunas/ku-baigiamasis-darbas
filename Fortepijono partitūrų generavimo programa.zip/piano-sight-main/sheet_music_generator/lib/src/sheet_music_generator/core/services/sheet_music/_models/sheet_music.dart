
import 'package:sheet_music_generator/src/sheet_music_generator/core/services/sheet_music/_models/voice.dart';

class SheetMusic {
  final List<Voice> voices = [];

  // Add a stave to the sheet music
  void addVoice(Voice voice) {
    voices.add(voice);
  }

  // Convert the entire sheet music to ABC notation
  String toABCString(int barsPerLine) {
    return voices.map((voice) => voice.toABCString(barsPerLine)).join("\n");
  }
}
