
enum Articulation {
  none,
  staccato,
  fermata,
}

enum NoteDuration {
  whole,
  half,
  quarter,
  eighth,
  sixteenth,

  halfdotted,
  quarterdotted,
  eighthdotted;

  // Get the duration of the note in beats based on the time signature
  double getDurationInBeats(int beatUnit) {
    switch (this) {
      case NoteDuration.whole:
        return 4.0 / (4 / beatUnit);
      case NoteDuration.half:
        return 2.0 / (4 / beatUnit);
      case NoteDuration.quarter:
        return 1.0 / (4 / beatUnit);
      case NoteDuration.eighth:
        return 0.5 / (4 / beatUnit);
      case NoteDuration.sixteenth:
        return 0.25 / (4 / beatUnit);

      case NoteDuration.halfdotted:
        return 3.0 / (4 / beatUnit);
      case NoteDuration.quarterdotted:
        return 1.5 / (4 / beatUnit);
      case NoteDuration.eighthdotted:
        return 0.75 / (4 / beatUnit);

      default:
        throw Exception("Unknown NoteDuration");
    }
  }
}

extension NoteDurationExtension on NoteDuration {
  String get abcDuration {
    switch (this) {
      case NoteDuration.whole:
        return '8';
      case NoteDuration.half:
        return '4';
      case NoteDuration.quarter:
        return '2';
      case NoteDuration.eighth:
        return '';
      case NoteDuration.sixteenth:
        return '/';


      case NoteDuration.halfdotted:
        return '6';
      case NoteDuration.quarterdotted:
        return '3';
      case NoteDuration.eighthdotted:
        return '3/2';
    }
  }
}