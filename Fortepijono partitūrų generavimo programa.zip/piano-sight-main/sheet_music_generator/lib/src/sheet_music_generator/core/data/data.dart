    final List<List<String>> octaveNotes = [
      ['C', '^B'],           
      ['^C', '_D'],          
      ['D'],           
      ['^D', '_E'],          
      ['E', '_F'],           
      ['F', '^E'],    
      ['^F', '_G'],           
      ['G'],          
      ['^G', '_A'],  
      ['A'],           
      ['^A', '_B'],           
      ['B', '_C']            
    ];