
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class Chord {
  final List<String> notes;
  final int bar;
  final double beat;
  final KeyType keyType;

  Chord({
    required this.notes,
    required this.bar,
    required this.beat,
    required this.keyType,
  });
}