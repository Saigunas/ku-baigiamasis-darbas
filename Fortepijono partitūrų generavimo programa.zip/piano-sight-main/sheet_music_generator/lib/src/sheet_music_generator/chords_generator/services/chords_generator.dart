import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/models/chord.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/services/chord_pattern_generator.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/services/chord_progression_generator.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/services/sheet_music/services/sheet_music_service.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class ChordsGenerator {
  final ChordProgressionGenerator _chordProgressionGenerator = ChordProgressionGenerator();
  final ChordPatternGenerator _chordPatternGenerator = ChordPatternGenerator();

  SheetMusicConfig sheetMusicConfig;
  GeneratorConfig generatorConfig;
  final SheetMusicService sheetMusic;

  ChordsGenerator({
    required this.sheetMusicConfig,
    required this.generatorConfig,
    required this.sheetMusic,
  });

  List<Chord> generateChords() {
    List<Chord> chords = _chordProgressionGenerator.createChordProgression(generatorConfig, sheetMusicConfig);
    List<NoteGroup> chordsNoteGroups = _chordPatternGenerator.generateChordPatterns(chords, generatorConfig, sheetMusicConfig);
    
    for(NoteGroup chordNoteGroup in chordsNoteGroups) {
      sheetMusic.addNoteGroupToSheetMusic(chordNoteGroup);
    }

    return chords;
  }
}