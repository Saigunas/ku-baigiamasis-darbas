import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/data/chord_progression_data.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/models/chord.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/utils/chord_helper.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';


class ChordProgressionGenerator {
  final ChordHelper _chordHelper = ChordHelper();

  List<Chord> createChordProgression(GeneratorConfig generatorConfig, SheetMusicConfig sheetMusicConfig) {
    final random = Random();
    final style = generatorConfig.style;
    final chordProgressions = chordProgressionDictionary[style] ?? [];

    if (chordProgressions.isEmpty) {
      throw Exception('No chord progressions available for style: $style');
    }
    int randomIndex = random.nextInt(chordProgressions.length);

    // chordProgressionDefinition contains chord names
    List<String> chordProgressionDefinition = chordProgressions[randomIndex];

    // Get length of chords
    var chordLengths = _selectChordTimingContext(style, chordProgressionDefinition.length);
    return _applyChordsToProgression(chordProgressionDefinition, chordLengths, sheetMusicConfig);
  }

  List<Chord> _applyChordsToProgression(List<String> chordProgressionDefinition, String chordContextTime, SheetMusicConfig sheetMusicConfig) {
    // appliedChordProgression contains chord notes
    List<Chord> appliedChordProgression = [];
    
    List<Map<String, num>> chordsTimingList = _chordHelper.parseChordContextTime(chordContextTime, sheetMusicConfig.time.beats, sheetMusicConfig.bars.value);
    for(int index = 0, chordNumber = 1; index < chordProgressionDefinition.length; index++, chordNumber++) {
      String chord = chordProgressionDefinition[index];
      List<String> notes = _chordHelper.getChordNotes(chord, sheetMusicConfig.keyType);

      List<Map<String, num>> chordTimingList = chordsTimingList.where(
        (chord) => chord['chordNumber'] == chordNumber
      ).toList();
      
      for(var chordTiming in chordTimingList) {
        appliedChordProgression.add(
          Chord(
            notes: notes,
            keyType: _chordHelper.getChordType(chord),
            bar:   ((chordTiming['bar']) ?? 0).toInt() - 1, // 0-indexed
            beat:     (chordTiming['beat'] ?? 0) * 1.0 - 1, // 0-indexed
          )
        );
      }
    }



    return appliedChordProgression;
  }

  String _selectChordTimingContext(Style style, int numberOfChords) {
    final random = Random();
    // Select chord progression timing
    List<Map<String, dynamic>> chordProgressionContextTimes = chordProgressionContextTimeDictionary[style] ?? [];
    if(chordProgressionContextTimes.isEmpty) {
      throw Exception('No chord progression context times available for style: $style');
    }

    final possibleProgressionContextTimes = chordProgressionContextTimes.where((progression) {
      if(progression == {}) {
        return false;
      }
      return (progression as Map)['numberOfChords'] == numberOfChords;
    }).toList();

    if (possibleProgressionContextTimes.isEmpty) {
      throw Exception('No possible progression found for number of chords: $numberOfChords');
    }

    var progressionContextTimes = possibleProgressionContextTimes[random.nextInt(possibleProgressionContextTimes.length)];
    return progressionContextTimes['chordContextTime'];
  }
}
