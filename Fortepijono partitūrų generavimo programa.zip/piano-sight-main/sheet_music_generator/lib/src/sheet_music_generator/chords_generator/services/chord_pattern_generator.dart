import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/data/chord_progression_data.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/models/chord.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/data/data.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';


class ChordPatternGenerator {
  Map<Style, Map<Time, List<Map<String, dynamic>>>> chordPatterns = chordPatternDictionary;

  List<NoteGroup> generateChordPatterns(List<Chord> chords, GeneratorConfig generatorConfig, SheetMusicConfig sheetMusicConfig) {
    List<NoteGroup> chordsNoteGroups = [];
    Map<String, dynamic> chordPatternType = _getRandomChordPattern(difficulty: generatorConfig.difficulty, time: sheetMusicConfig.time, style: generatorConfig.style);

    for(Chord chord in chords) {
      List<String> pitches = [];
      for(String pitch in chord.notes) {
        pitches.add(pitch);
      }
      
      List<NoteGroup> noteGroups = _createChordPattern(pitches, chord, sheetMusicConfig.clefs.length, chordPatternType);
      chordsNoteGroups.addAll(noteGroups);
    }

    return chordsNoteGroups;
  }

  List<NoteGroup> _createChordPattern(List<String> pitches, Chord chord, int voiceLineId, Map<String, dynamic> chordPatternType) {
    List<Map<String, dynamic>> chordPatterns = _getPatternVariationByPitchCount(patternType: chordPatternType['pattern'], pitchCount: pitches.length);
    List<NoteGroup> noteGroups = _applyChordPattern(pitches, chordPatterns, chord.bar, voiceLineId);
    _applyOctaveModifiers(noteGroups, chordPatternType['octaves'] ?? [3], chordPatterns);
    return noteGroups;
  }

  List<NoteGroup> _applyChordPattern(List<String> chordPitches, List<Map<String, dynamic>> pattern, int barNumber, int voiceLineId) {
    List<NoteGroup> noteGroups = [];
    
    // Extract the bar structure from the pattern
    List<Map<String, dynamic>> barStructure = pattern;
    
    for (Map<String, dynamic> noteData in barStructure) {
      NoteDuration duration = noteData['duration'];
      
      List<int> pitchIndexes = List<int>.from(noteData['pitchIndexes']);
      
      List<String> selectedPitches = pitchIndexes.map((index) => chordPitches[index]).toList();
      
      NoteGroup noteGroup = NoteGroup(
        pitches: selectedPitches,
        voiceLineId: voiceLineId,
        bar: barNumber,
        duration: duration,
      );
      
      noteGroups.add(noteGroup);
    }
    
    return noteGroups;
  }

  Map<String, dynamic> _getRandomChordPattern({
    required Style style,
    required Time time,
    required Difficulty difficulty,
  }) {
    // Get the available patterns for the specified style and time
    List<Map<String, dynamic>>? availablePatternsForStyle = chordPatterns[style]?[time];

    if (availablePatternsForStyle == null || availablePatternsForStyle.isEmpty) {
      throw Exception('No chord patterns available for the style: $style and time: $time');
    }

    // Filter to find patterns that match the specified difficulty
    List<Map<String, dynamic>> patternsForDifficulty = availablePatternsForStyle.where((pattern) {
      return (pattern['difficulty'] as List<Difficulty>).contains(difficulty);
    }).toList();

    if (patternsForDifficulty.isEmpty) {
      throw Exception('No chord patterns available for the style: $style, time: $time with difficulty: $difficulty');
    }

    // choose random pattern from paternsForDifficulty.
    Random random = Random();
    int randomPatternIndex = random.nextInt(patternsForDifficulty.length);
    Map<String, dynamic> selectedPatternType = patternsForDifficulty[randomPatternIndex];

    return selectedPatternType;
  }

  List<Map<String, dynamic>> _getPatternVariationByPitchCount({
    required List<Map<String, dynamic>> patternType,
    required int pitchCount,
  }) {
    List<Map<String, dynamic>> patternByPitchCount = patternType.firstWhere((pattern) => 
      pattern['pitchCount'] == pitchCount
    )['bar'].toList();

    if (patternByPitchCount.isEmpty) {
      throw Exception('No chord pattern variation available for provided pitch count: $pitchCount');
    }

    return patternByPitchCount;
  }


  List<NoteGroup> _applyOctaveModifiers(List<NoteGroup> listOfNoteGroups,
      List<int> octaves, List<Map<String, dynamic>> pattern) {

    List<ChordDirection> chordDirections = _getChordDirections(pattern);
    final List<String> octavePitchModifier = [
      ',,,,',
      ',,,',
      ',,',
      ',',
      '',
      "'",
      "''",
      "'''",
      "''''",
    ];


    int previousNoteGroupPitchOctaveIndex = -1;
    int currentOctaveIndex = 0;

    for (int noteGroupIndex = 0;
        noteGroupIndex < listOfNoteGroups.length;
        noteGroupIndex++) {
      ChordDirection chordDirection = chordDirections[noteGroupIndex];
      List<String> pitches = listOfNoteGroups[noteGroupIndex].pitches;

      // Used to assess chord direction for getting correct modifier of the first pitch in a list
      int previousPitchOctaveIndex = -1;

      List<String> updatedPitches = [];
      // Apply modifiers for each pitch in the note group
      for (int pitchIndex = 0; pitchIndex < pitches.length; pitchIndex++) {
        String pitch = pitches[pitchIndex];
        int currentPitchOctaveIndex = octaveNotes.indexWhere((element) => element.contains(pitch.toUpperCase()));

        // If pitch is first in the list
        if (pitchIndex == 0) {
          // pitch is not the first pitch in the whole bar
          if (previousNoteGroupPitchOctaveIndex != -1) {
            // depending on the Chord direction, change current octave
            if (chordDirection == ChordDirection.descending &&
                currentPitchOctaveIndex >= previousNoteGroupPitchOctaveIndex) {
              currentOctaveIndex--;
            }

            if (chordDirection == ChordDirection.ascending &&
                currentPitchOctaveIndex <= previousNoteGroupPitchOctaveIndex) {
              currentOctaveIndex++;
            }
          }

          currentOctaveIndex = currentOctaveIndex.clamp(0, octaves.length - 1);
          // Keep track of the first pitch in the noteGroup
          previousNoteGroupPitchOctaveIndex = currentPitchOctaveIndex;
        }

        // NoteGroup pitches are ascending by design
        if (pitchIndex > 0 &&
            currentPitchOctaveIndex <= previousPitchOctaveIndex) {
          currentOctaveIndex++;
          currentOctaveIndex = currentOctaveIndex.clamp(0, octaves.length - 1);
        }

        int currentOctave = octaves[currentOctaveIndex];

        String modifiedPitch = pitch + octavePitchModifier[currentOctave];

        updatedPitches.add(modifiedPitch);
        previousPitchOctaveIndex = currentPitchOctaveIndex;
      }
      listOfNoteGroups[noteGroupIndex].pitches.removeWhere((element) => true);
      listOfNoteGroups[noteGroupIndex].pitches.addAll(updatedPitches);
    }
    return listOfNoteGroups;
  }

  List<ChordDirection> _getChordDirections(List<Map<String, dynamic>> pattern) {
    List<ChordDirection> chordDirections = [];

    for (var item in pattern) {
      chordDirections.add(item['chordDirection'] ?? ChordDirection.static);
    }

    return chordDirections;
  }
}