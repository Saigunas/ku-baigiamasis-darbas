
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class ChordHelper {
  static const Map<String, List<int>> chordDictionary = {
    'maj': [0, 4, 7],                           // Major triad
    'min': [0, 3, 7],                           // Minor triad
    'dim': [0, 3, 6],                           // Diminished triad
    'aug': [0, 4, 8],                           // Augmented triad
    'maj6': [0, 4, 7, 8],                       // Major 6th
    'dom7': [0, 4, 7, 10],                         // Dominant 7th
    'maj7': [0, 4, 7, 11],                      // Major 7th
    'min7': [0, 3, 7, 10],                      // Minor 7th
    'dim7': [0, 3, 6, 9],                       // Diminished 7th
    'maj9': [0, 4, 7, 11, 14],                  // Major 9th
    'min9': [0, 3, 7, 10, 14],                  // Minor 9th
    'dom9': [0, 4, 7, 10, 14],                     // Dominant 9th
    'maj11': [0, 4, 7, 11, 14, 17],             // Major 11th
    'min11': [0, 3, 7, 10, 14, 17],             // Minor 11th
    'dom11': [0, 4, 7, 10, 14, 17],                // Dominant 11th
    'maj13': [0, 4, 7, 11, 14, 17, 21],         // Major 13th
    'min13': [0, 3, 7, 10, 14, 17, 21],         // Minor 13th
    'dom13': [0, 4, 7, 10, 14, 17, 21],            // Dominant 13th
  };

  static const Map<String, String> majorScaleDegreesToNotes = {
    '1': 'C',
    '♭1': '_C',
    '♯1': '^C',
    '♭2': '_D',
    '2': 'D',
    '♯2': '^D',
    '♭3': '_E',
    '3': 'E',
    '♯3': '^E',
    '4': 'F',
    '♯4': '^F',
    '♭5': '_G',
    '5': 'G',
    '♯5': '^G',
    '♭6': '_A',
    '6': 'A',
    '♯6': '^A',
    '♭7': '_B',
    '7': 'B',
    '♯7': '^B'
  };
  // if we move from _D two steps up, we seek _E not ^D for consistency.
  final Map<int, Map<int, String>> stepsToNotes = {
    0: {0: 'C', 1: '^B'},
    1: {1: '^C', -1: '_D'},
    2: {0: 'D'},
    3: {1: '^D', -1: '_E'},
    4: {0: 'E', -1: '_F'},
    5: {0: 'F', 1: '^E'},
    6: {1: '^F', -1: '_G'},
    7: {0: 'G'},
    8: {1: '^G', -1: '_A'},
    9: {0: 'A'},
    10: {1: '^A', -1: '_B'},
    11: {0: 'B', -1: '_C'},
  };

  KeyType getChordType(String chord) {
    final match = RegExp(r'([♭♯]?[1-7])([a-z]+\d*)').firstMatch(chord);
    
    if (match == null) {
      throw Exception('Invalid chord format: $chord');
    }
    final String chordType = match.group(2) ?? '';
    
    KeyType keyType = KeyType.major;
    switch (chordType) {
      case 'maj':
        keyType = KeyType.major;
        break;
      case 'min': 
        keyType = KeyType.minor;
        break;
    }

    return keyType;
  }

  List<String> getChordNotes(String chord, KeyType keyType) {
    // Use regex to match the root note and the chord type
    final match = RegExp(r'([♭♯]?[1-7])([a-z]+\d*)').firstMatch(chord);
    
    if (match == null) {
      throw Exception('Invalid chord format: $chord');
    }

    // Extract the root and chord type
    final String rootString = match.group(1) ?? ''; // e.g., '2' or '♭2'
    final String chordType = match.group(2) ?? ''; // e.g., 'maj', 'min'
    final String rootNote = majorScaleDegreesToNotes[rootString] ?? '';
    if(rootNote.isEmpty) {
      throw Exception('Root note not found: $rootString');
    }

    List<String> chordNotes = [];
    if(keyType == KeyType.major) {

      final chordIntervals = chordDictionary[chordType] ?? [];

      if (chordIntervals.isEmpty) {
        throw Exception('ChordType: $chordType, not found');
      }
      
      // Find notes of the chord
      for (var steps in chordIntervals) {
        chordNotes.add(getNoteAfterSteps(rootNote, steps, chordType));
      }
    } else {
      throw Exception('KeyType: $keyType, not supported');
    }

    return chordNotes;
  }

  String getNoteAfterSteps(String note, int steps, String chordType) {
    int currentStep = -1;
    int currentModifier = 0;

    // Find the current step and modifier
    for (var step in stepsToNotes.keys) {
      for (var modifier in stepsToNotes[step]!.keys) {
        if (stepsToNotes[step]![modifier] == note) {
          currentStep = step;
          currentModifier = modifier;
          break;
        }
      }
    }

    if (currentStep == -1) {
      throw Exception('Note: $note, not found');
    }

    // Calculate the new step after adding steps
    int newStep = (currentStep + steps) % 12;
    if (newStep < 0) newStep += 12;

    // Try to find a note with the same modifier
    if (stepsToNotes[newStep]!.containsKey(currentModifier)) {
      return stepsToNotes[newStep]![currentModifier]!;
    }

    // If not found, try to get the natural note (modifier 0)
    if (stepsToNotes[newStep]!.containsKey(0)) {
      return stepsToNotes[newStep]![0]!;
    }

    // If the current modifier is 0 and no natural note is found, use modifier according to chord type
    if (currentModifier == 0) {
      if(chordType.contains('min') || chordType.contains('dim') || chordType.contains('dom')) {
        return stepsToNotes[newStep]![-1]!;
      }
      // maj, aug, and others
      return stepsToNotes[newStep]![1]!;
    }

    throw Exception('Note: $note, not found');
  }

  List<Map<String, num>> parseChordContextTime(String chordContextTimes, int beatCount, int amountOfBars) {
    chordContextTimes = _adjustChordsContextTimesToFillBars(chordContextTimes, amountOfBars);
    List<String> bars = chordContextTimes.split('|');
    List<Map<String, num>> chordsTimingList = [];

    for (int barIndex = 0; barIndex < bars.length; barIndex++) {
      String bar = bars[barIndex];

      if (bar.isEmpty) continue;

      int chordCount = bar.length;
        
      // Calculate the duration each chord should occupy in terms of beats
      double beatsPerChord = beatCount / chordCount;

      // For each chord in the bar, create a Chord object
      for (int chordIndex = 0; chordIndex < chordCount; chordIndex++) {
        int chordNumber = int.parse(bar[chordIndex]);
        double beatStart = chordIndex * beatsPerChord + 1;

        // Add the Chord to the list
        chordsTimingList.add({
          'chordNumber': chordNumber,
          'bar': barIndex + 1,  // Bars are 1-indexed
          'beat': beatStart,    // Beat is 1-indexed
        });
      }
    }

    return chordsTimingList;
  }

  String _adjustChordsContextTimesToFillBars(String chordContextTimes, int amountOfBars) {
    
    if(amountOfBars < 0) {
      throw Exception('amountOfBars: $amountOfBars, is invalid');
    }
    if (chordContextTimes.isEmpty) {
      throw Exception('chordContextTimes: $chordContextTimes, can not be empty');
    }

    // Remove the last |
    chordContextTimes = chordContextTimes.substring(0, chordContextTimes.length - 1);

    List<String> bars = chordContextTimes.split('|');
    if(bars.isEmpty) {
      throw Exception('chordContextTimes: $chordContextTimes, failed to retrieve bars');
    }

    // If the input has more bars than needed, truncate the list
    if (bars.length > amountOfBars) {
      bars = bars.sublist(0, amountOfBars);
    } 
    // If the input has fewer bars, loop them until the desired number of bars is reached
    else if (bars.length < amountOfBars) {
      while (bars.length < amountOfBars) {
        bars.addAll(bars.sublist(0, amountOfBars - bars.length));
      }
    }

    // Join the bars back together using '|' and ensure a trailing '|'
    return '${bars.join('|')}|';
  }
}
