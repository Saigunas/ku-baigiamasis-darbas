enum ChordDirection {
  ascending,
  descending, 
  static,
}