import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';

const Map<Style, List<List<String>>> chordProgressionDictionary = {
  Style.classical: [
    ['1maj', '5maj', '6min', '4maj'],
    ['6min', '4maj', '1maj', '5maj'],
    ['1maj', '4maj', '6min', '5maj'],
    ['1maj', '6min', '4maj', '5maj'],
    ['1maj', '6min', '2min', '5maj'],
    ['4maj', '1maj',  '6min', '5maj'],

// https://www.guitarlobby.com/classical-chord-progressions/
/*
['1maj', '5maj', '6min', '4maj'], // (I – V – vi – IV) The Beatles - Let It Be
['2min', '5maj', '1maj'], // (ii – V – I) Maroon 5 - Sunday Morning
['1maj', '6min', '4maj', '5maj'], // (I – vi – IV – V) The Police - Every Breath You Take
['1maj', '4maj', '5maj'], // (I – IV – V) Ritchie Valens - La Bamba
['1maj', '5maj', '6min', '3min', '4maj', '1maj', '4maj', '5maj'], // (I – V – vi – iii – IV – I – IV – V) Green Day - Basket Case
['1min', '1min7', '4Maj', '6Maj'], // (i – i – IV – VI) The Beatles - While My Guitar Gently Weeps
['6min', '5maj', '4maj', '3maj'], // (vi – V – IV – III) Michael Jackson - Smooth Criminal
['1maj', '♭7maj', '4maj'], // (I – bVII – IV) Blink-182 - All the Small Things
['1maj', '6min', '2min', '5maj'], // (I – vi – ii – V) Harry Nilsson - Without You
['1min', '♭6maj', '♭3maj', '♭7maj'], // (i – bVI – bIII – bVII) OneRepublic - Apologize
['1maj', '4maj', '6min', '5maj'], // (I – IV – vi – V) OneRepublic - Good Life
['6min', '4maj', '1maj', '5maj'], // (vi – IV – I – V) Toto - Africa
['♭6maj', '♭7maj', '1maj'], // (bVI – bVII – I) Stevie Wonder - I Was Made to Love Her
['1maj', '1aug', '1maj6', '1maj7'], // (I – I+ – I6 – I7) Whitney Houston - Greatest Love of All
['4maj', '1maj', '6min', '5maj'], // (IV – I – vi – V) Backstreet Boys - As Long As You Love Me
*/
  ],       
  Style.anime: [
    // https://chromaticdreamers.com/analyzing-anime-song-chord-progressions/
    ['4maj', '5maj', '3min', '6min'], // From minor (VI – VII – i – IV) "Again" from Fullmetal Alchemist by Yui
    ['4maj', '5maj', '6min', '3min'], // From minor (VI – VII – i – III) "Unravel" from Tokyo Ghoul by Ling Tosite Sigure
    ['4maj', '5maj', '6min', '1maj'], // (IV – V – vi – I) "Peace Sign" from My Hero Academia by Kenshi Yonezu
    ['6min', '2min', '5maj', '1maj'], // (vi – ii – V – I) "Inferno" from Fire Force by Mrs. Green Apple
    ['1maj', '5maj', '6min', '3min'], // (I – V – vi – iii) "Butterfly" from Digimon by Kouji Wada
    // ['4maj', '5maj', '6min'], // (IV – V – vi) "Hikaru Nara" from Your Lie In April by Goose House
    ['4maj', '5maj', '6min', '5maj'], // (IV – V – vi) "Hikaru Nara" from Your Lie In April by Goose House
    ['4maj', '5maj', '3min', '6min'], // (IV – V – iii – vi) "God Knows" from Haruhi Suzumiya by Aya Hirano

    // Temporally removed - any non standart chords sound good only in certain cases
   // ['1maj', '3maj', '6min', '5min'], // (I – III – vi – v) "Departure" from Hunter x Hunter by Masatoshi Ono, // IV-II-V-VI 
   // ['1maj', '5maj', '6min', '5min'], // (I – V – vi – v) "Again" from Fruits Basket by Beverly
  ],                                  
};

const chordProgressionContextTimeDictionary = {
  Style.classical: [
    {
      'progressionName': 'Basic classical Progression',
      'numberOfChords': 4,
      'chordContextTime': '1|2|3|4|'
    },
  ],
  Style.anime: [
    {
      'progressionName': 'Basic anime Progression',
      'numberOfChords': 4,
      'chordContextTime': '1|2|3|4|'
    },
  ]                                       
};

final Map<Style, Map<Time, List<Map<String, dynamic>>>> chordPatternDictionary = {
  Style.classical: {
    Time.four_four: [
// Difficulty one
      {
        'difficulty': [Difficulty.one],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0]
              },
            ]
          },
          {
            'pitchCount': 4,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0]
              },
            ]
          },
        ],
      },



// Difficulty two      


      {
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [2],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [3],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
        ],
      },


// Difficulty 3
      {
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0, 1, 2]
              },
            ]
          },
          {
            'pitchCount': 4,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0, 1, 3]
              },
            ]
          },
        ],
      },
      {
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
                'chordDirection': ChordDirection.descending,
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
                'chordDirection': ChordDirection.ascending,

              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [2],
                'chordDirection': ChordDirection.ascending,
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [3],
              },
            ]
          },
        ],
      },


      {
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
            ]
          },
        ],
      },



      {
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1,2],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1,3],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0, 1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0, 1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0, 3],
                'chordDirection': ChordDirection.descending,
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0, 3],
                'chordDirection': ChordDirection.static,
              },
            ]
          },
        ],
      },


// Difficulty 4
      {
        'difficulty': [Difficulty.four],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [2],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [3],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.four],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1,2],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [2,3],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.four],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0,1],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [2],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0,3],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [2],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
            ]
          },
        ],
      },
    ],
  },
  Style.anime: {
    Time.four_four: [
// Difficulty one
      { // Different from classical
        'difficulty': [Difficulty.one],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0]
              },
            ]
          },
          {
            'pitchCount': 4,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0]
              },
            ]
          },
        ],
      },



// Difficulty two   
      { // Different from classical
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0, 1]
              },
            ]
          },
          {
            'pitchCount': 4,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0, 1]
              },
            ]
          },
        ],
      },
      {//different from classical
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [2],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [3],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.two],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
        ],
      },
// Difficulty 3

      { // different from classical
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
        ],
      },
      {
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0, 1, 2]
              },
            ]
          },
          {
            'pitchCount': 4,
            'bar': [
              {
                'duration': NoteDuration.whole,
                'pitchIndexes': [0, 1, 3]
              },
            ]
          },
        ],
      },
      {
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
                'chordDirection': ChordDirection.descending,
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
                'chordDirection': ChordDirection.ascending,

              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [2],
                'chordDirection': ChordDirection.ascending,
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [3],
              },
            ]
          },
        ],
      },


      { // different from classical
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.eighth,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.eighth,
                'pitchIndexes': [1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.eighth,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.eighth,
                'pitchIndexes': [1],
              },
            ]
          },
        ],
      },



      {
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1,2],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1,3],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0, 1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0, 1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0, 3],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [0, 3],
              },
            ]
          },
        ],
      },

      { // different from classical
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0,1],
              },
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0,1],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0,1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0,1],
              },
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0,1],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0,1],
              },
            ]
          },
        ],
      },

      {// different from classical
        'difficulty': [Difficulty.three],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0,1,2],
              },
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0,1,2],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0,1,2],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0,1,3],
              },
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0,1,3],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0,1,3],
              },
            ]
          },
        ],
      },

// Difficulty 4
      {
        'difficulty': [Difficulty.four],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [2],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [3],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
            ]
          },
        ],
      },

      {
        'difficulty': [Difficulty.four],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [1,2],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.half,
                'pitchIndexes': [2,3],
              },
            ]
          },
        ],
      },

      { // different from classical
        'difficulty': [Difficulty.four],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.eighth,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.eighth,
                'pitchIndexes': [1],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.eighth,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.eighth,
                'pitchIndexes': [1],
              },
            ]
          },
        ],
      },


      { // different from classical
        'difficulty': [Difficulty.four],
        'octaves': [3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [2],
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [3],
            'bar': [
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarterdotted,
                'pitchIndexes': [1],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [2],
              },
            ]
          },
        ],
      },

      { // different from classical
        'difficulty': [Difficulty.four],
        'octaves': [2,3],
        'pattern': [
          {
            'pitchCount': 3,
            'bar': [
              {
                'duration': NoteDuration.halfdotted,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [1],
                'direction': ChordDirection.ascending
              },
            ]
          },
          {
            'pitchCount': 4,
            'octaves': [2,3],
            'bar': [
              {
                'duration': NoteDuration.halfdotted,
                'pitchIndexes': [0],
              },
              {
                'duration': NoteDuration.quarter,
                'pitchIndexes': [3],
                'direction': ChordDirection.ascending
              },
            ]
          },
        ],
      },

    ],
  },
};