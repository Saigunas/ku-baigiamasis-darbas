import 'package:flutter_test/flutter_test.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/data/enums.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/core/models/note_group.dart';
import 'dart:math';

import 'package:sheet_music_generator/src/sheet_music_generator/melody_generator/utils/melody_helper.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

void main() {
  group('MelodyHelper Tests', () {
    
    test('groupNoteGroupsByBar should group notes correctly', () {
      final melodyHelper = MelodyHelper();
      
      final noteGroups = [
        NoteGroup(bar: 1, pitches: ['C', 'E'], voiceLineId: 1, duration: NoteDuration.whole),
        NoteGroup(bar: 1, pitches: ['G', 'B'], voiceLineId: 1, duration: NoteDuration.whole),
        NoteGroup(bar: 2, pitches: ['D', 'F'], voiceLineId: 1, duration: NoteDuration.whole),
      ];

      final result = melodyHelper.groupNoteGroupsByBar(noteGroups);
      
      expect(result[1], isNotNull);
      expect(result[1]!.length, 2);
      expect(result[2], isNotNull);
      expect(result[2]!.length, 1);
    });

    test('mapPentatonicToNoteList should map notes correctly', () {
      final melodyHelper = MelodyHelper();
      final notes = ['C', 'D', 'E', 'F', 'G'];
      final pentatonicScale = ['C', 'D', 'E', 'G', 'A'];  // Example pentatonic scale

      final result = melodyHelper.mapPentatonicToNoteList(notes, pentatonicScale);
      
      expect(result.length, 5);
      expect(result.contains('F'), false);
      expect(result[0], 'C');
      expect(result[1], 'D');
      expect(result[2], 'E');
      expect(result[3], 'E');
      expect(result[4], 'G');
    });

    test('appendRandomPitchToNoteGroup should add a random pitch to the note group', () {
      final melodyHelper = MelodyHelper();
      final noteGroup = NoteGroup(bar: 1, pitches: ['C', 'E'], voiceLineId: 1, duration: NoteDuration.whole);
      final random = Random();
      final scale = ['C', 'D', 'E', 'F', 'G'];

      final initialLength = noteGroup.pitches.length;
      melodyHelper.appendRandomPitchToNoteGroup(noteGroup, random, scale);

      expect(noteGroup.pitches.length, greaterThan(initialLength));
    });

    test('getPentatonicScale should return correct scale for major key', () {
      final melodyHelper = MelodyHelper();
      final pitch = 'C';
      final keyType = KeyType.major;  // Assuming KeyType is defined somewhere

      final result = melodyHelper.getPentatonicScale(pitch, keyType);
      
      expect(result, ['C', 'D', 'E', 'G', 'A']);
    });

    test('getPentatonicScale should return correct scale for minor key', () {
      final melodyHelper = MelodyHelper();
      final pitch = 'G';
      final keyType = KeyType.minor;  // Assuming KeyType is defined somewhere

      final result = melodyHelper.getPentatonicScale(pitch, keyType);
      
      expect(result.every((item) => ['G', '_B', 'C', 'D', 'F'].contains(item)), true);
    });


    test('findClosestNoteMatch should find the correct closest note', () {
      final melodyHelper = MelodyHelper();
      final scale = ['C', 'D', 'E', 'G', 'A'];

      final result = melodyHelper.findClosestNoteMatch(scale, 'F');

      expect(result, 'E'); // Assuming F is closest to E in this case
    });
  });
}
