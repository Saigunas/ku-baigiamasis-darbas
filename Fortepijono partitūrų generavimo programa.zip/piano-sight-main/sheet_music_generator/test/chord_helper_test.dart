import 'package:flutter_test/flutter_test.dart';
import 'package:sheet_music_generator/src/sheet_music_generator/chords_generator/utils/chord_helper.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
void main() {
  final chordHelper = ChordHelper();

  group('ChordHelper', () {
    group('getChordType', () {
      test('should return correct chord type for "1maj"', () {
        expect(chordHelper.getChordType('1maj'), KeyType.major);
      });

      test('should return correct chord type for "2min"', () {
        expect(chordHelper.getChordType('2min'), KeyType.minor);
      });

      test('should throw exception for invalid chord format', () {
        expect(() => chordHelper.getChordType('invalidChord'), throwsException);
      });
    });

    group('getChordNotes', () {
      test('should return correct notes for "1maj" chord in major key', () {
        final notes = chordHelper.getChordNotes('1maj', KeyType.major);
        expect(notes, ['C', 'E', 'G']); // Based on the major scale and intervals.
      });

      test('should return correct notes for "2min" chord in major key', () {
        final notes = chordHelper.getChordNotes('2min', KeyType.major);
        expect(notes, ['D', 'F', 'A']); // Based on the major scale and intervals.
      });

      test('should return correct notes for "2dim7" chord in major key', () {
        final notes = chordHelper.getChordNotes('2dim7', KeyType.major);
        expect(notes, ['D', 'F', '_A', 'B']); // Based on the major scale and intervals.
      });

      test('should throw exception for unsupported key type', () {
        expect(() => chordHelper.getChordNotes('1maj', KeyType.minor),
            throwsException);
      });

      test('should throw exception for invalid chord format', () {
        expect(() => chordHelper.getChordNotes('invalidChord', KeyType.major),
            throwsException);
      });
    });

    group('getNoteAfterSteps', () {
      test('should return correct note for steps from C', () {
        expect(chordHelper.getNoteAfterSteps('C', 4, 'maj'), 'E');
      });

      test('should return correct note for steps from F in minor', () {
        expect(chordHelper.getNoteAfterSteps('F', 3, 'min'), '_A');
      });

      test('should throw exception for invalid note', () {
        expect(() => chordHelper.getNoteAfterSteps('H', 4, 'maj'),
            throwsException);
      });
    });

  group('parseChordContextTime', () {
    test('parses a single bar with equal beat divisions', () {
      final result = chordHelper.parseChordContextTime('1234|', 4, 1);
      expect(result, [
        {'chordNumber': 1, 'bar': 1, 'beat': 1.0},
        {'chordNumber': 2, 'bar': 1, 'beat': 2.0},
        {'chordNumber': 3, 'bar': 1, 'beat': 3.0},
        {'chordNumber': 4, 'bar': 1, 'beat': 4.0},
      ]);
    });

    test('parses multiple bars with consistent beat divisions', () {
      final result = chordHelper.parseChordContextTime('12|34|', 4, 2);
      expect(result, [
        {'chordNumber': 1, 'bar': 1, 'beat': 1.0},
        {'chordNumber': 2, 'bar': 1, 'beat': 3.0},
        {'chordNumber': 3, 'bar': 2, 'beat': 1.0},
        {'chordNumber': 4, 'bar': 2, 'beat': 3.0},
      ]);
    });

    test('handles unequal chord lengths within a bar', () {
      final result = chordHelper.parseChordContextTime('123|', 6, 1);
      expect(result, [
        {'chordNumber': 1, 'bar': 1, 'beat': 1.0},
        {'chordNumber': 2, 'bar': 1, 'beat': 3.0},
        {'chordNumber': 3, 'bar': 1, 'beat': 5.0},
      ]);
    });

    test('throws exception for empty input', () {
      expect(() => chordHelper.parseChordContextTime('', 4, 2), throwsException);
    });
  });

  });
}
