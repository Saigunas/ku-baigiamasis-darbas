import 'package:sheet_music_generator/sheet_music_generator.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:test/test.dart';

void main() {
  group('SheetMusicGenerator', () {
    late SheetMusicConfig sheetMusicConfig;
    late GeneratorConfig generatorConfig;
    late SheetMusicGenerator sheetMusicGenerator;

    setUp(() {
      sheetMusicConfig = SheetMusicConfig(
        keyType: KeyType.major,
        bars: Bars.eight,
        time: Time.four_four,
        clefs: [Clef.treble, Clef.bass]
      );
      generatorConfig = GeneratorConfig(style: Style.classical, difficulty: Difficulty.one);
      sheetMusicGenerator = SheetMusicGenerator(sheetMusicConfig: sheetMusicConfig, generatorConfig: generatorConfig);
    });

    test('should return generated string', () {
      String abcMusic = sheetMusicGenerator.generateSheetMusic();

      // Validate global structure
      expect(abcMusic, contains('K: '), reason: 'Missing key signature (K:)');
      expect(abcMusic, contains('%%staves'), reason: 'Missing staves definition (%%staves)');
      expect(abcMusic, contains('V:1 clef=treble'), reason: 'Missing Voice 1 definition');
      expect(abcMusic, contains('V:2 clef=bass'), reason: 'Missing Voice 2 definition');

      // Use regex .*?\| to find all bars
      RegExp barRegex = RegExp(r'.*?\|');
      final matches = barRegex.allMatches(abcMusic);
      int totalBarCount = sheetMusicConfig.bars.value * sheetMusicConfig.clefs.length;
      expect(matches.toList().length, totalBarCount, reason: 'Incorrect amount of bars');
      
      // Validate each bar
      for (final match in matches) {
        final bar = match.group(0)?.trim() ?? '';
        bar.replaceAll(' ', '');
        // Ensure bar is non-empty and contains something valid
        expect(bar.isNotEmpty, isTrue, reason: 'Found an empty bar');
      }
    });
  });
}