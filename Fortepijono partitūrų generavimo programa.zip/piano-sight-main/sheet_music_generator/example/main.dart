import 'package:abc_dart/src/controllers/sheet_music_viewer_controller.dart';

import 'controllers/sheet_music_controller.dart';
import 'package:abc_dart/main.dart';
import 'package:flutter/material.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

void main() {
  runApp(
    MaterialApp(
      home: const SheetMusicGeneratorApp(),
    ),
  );
}

class SheetMusicGeneratorApp extends StatefulWidget {
  const SheetMusicGeneratorApp({super.key});

  @override
  _SheetMusicGeneratorAppState createState() => _SheetMusicGeneratorAppState();
}

class _SheetMusicGeneratorAppState extends State<SheetMusicGeneratorApp> {
  late SheetMusicViewerController _sheetMusicViewerController;

  // Function to generate sheet music when button is pressed
  void _generateSheetMusic() {
    GeneratorConfig generatorConfig = GeneratorConfig(
      style: Style.anime,           // Example music style
      difficulty: Difficulty.three, // Example difficulty level
    );

    // Create a SheetMusicController that uses the WebViewController
    SheetMusicController sheetMusicController = SheetMusicController(
      sheetMusicViewerController: _sheetMusicViewerController,
    );

    // Call the method to generate sheet music
    sheetMusicController.generateSheetMusic(generatorConfig);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sheet Music Generator App'),
      ),
      body: Column(
        children: [
          // The WebViewApp widget integrated here with the callback
          Expanded(
            child: WebViewApp(
              onControllerCreated: (controller) {
                _sheetMusicViewerController = controller;  // Assign controller
              },
            ),
          ),
          // Button to trigger sheet music generation
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: _generateSheetMusic,
              child: const Text('Generate Sheet Music'),
            ),
          ),
        ],
      ),
    );
  }
}