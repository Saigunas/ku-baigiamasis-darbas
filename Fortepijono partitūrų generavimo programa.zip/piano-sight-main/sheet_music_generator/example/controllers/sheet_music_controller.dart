import 'package:abc_dart/src/controllers/sheet_music_viewer_controller.dart';
import 'package:sheet_music_generator/sheet_music_generator.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class SheetMusicController {
  final SheetMusicViewerController sheetMusicViewerController;

  late GeneratorConfig generatorConfig;
  late SheetMusicConfig sheetMusicConfig;
  late SheetMusicGenerator sheetMusicGenerator;

  SheetMusicController({
    required this.sheetMusicViewerController,
  }) {
    sheetMusicConfig = SheetMusicConfig(
      keyType: KeyType.major,
      bars: Bars.eight,
      time: Time.four_four,
      clefs: [Clef.treble, Clef.bass]
    );
    generatorConfig = GeneratorConfig(
      style: Style.anime,
      difficulty: Difficulty.three, 
    );
    sheetMusicGenerator = SheetMusicGenerator(sheetMusicConfig: sheetMusicConfig, generatorConfig: generatorConfig);
  }

  void generateSheetMusic(GeneratorConfig generatorConfig) {
    updateGeneratorConfig(generatorConfig);
    String generatedSheet = sheetMusicGenerator.generateSheetMusic();
    int transposeStep = sheetMusicGenerator.getTransposeStep();
    sheetMusicViewerController.displaySheetMusic(generatedSheet, transposeStep: transposeStep);
  }

  void updateGeneratorConfig(GeneratorConfig generatorConfig) {
    this.generatorConfig.difficulty = generatorConfig.difficulty;
    this.generatorConfig.style = generatorConfig.style;
  }
}

