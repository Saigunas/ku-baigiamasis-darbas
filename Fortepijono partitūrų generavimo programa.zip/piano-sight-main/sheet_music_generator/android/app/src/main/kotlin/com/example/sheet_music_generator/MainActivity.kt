package com.example.sheet_music_generator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
