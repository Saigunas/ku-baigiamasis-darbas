import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';
import 'package:storage/src/config_service.dart';
import 'package:test/expect.dart';
import 'package:test/scaffolding.dart';

void main() {
  group('ConfigService Tests', () {
    late String testFilePath;

    setUp(() async {
      // Get the application documents directory
      final directory = await getApplicationDocumentsDirectory();
      testFilePath = '${directory.path}/generator_config.json';
      
      // Clean up any existing file before each test
      final testFile = File(testFilePath);
      if (await testFile.exists()) {
        await testFile.delete();
      }
    });

    tearDown(() async {
      // Clean up the file after each test
      final testFile = File(testFilePath);
      if (await testFile.exists()) {
        await testFile.delete();
      }
    });

    test('saveConfig should save the GeneratorConfig to a file', () async {
      final config = GeneratorConfig(
        style: Style.pop,
        difficulty: Difficulty.one,
      );

      // Save the config
      await ConfigService.saveConfig(config);

      // Check if the file exists
      final file = File(testFilePath);
      expect(await file.exists(), isTrue);

      // Verify the content of the file
      final jsonString = await file.readAsString();
      final loadedConfig = GeneratorConfig.fromJson(jsonDecode(jsonString));
      expect(loadedConfig.style.name, config.style.name);
      expect(loadedConfig.difficulty.level, config.difficulty.level);
    });

    test('loadConfig should load the GeneratorConfig from a file', () async {
      final config = GeneratorConfig(
        style: Style.pop,
        difficulty: Difficulty.one,
      );

      // First, save the config
      await ConfigService.saveConfig(config);

      // Now, load the config
      final loadedConfig = await ConfigService.loadConfig();

      // Verify the loaded config
      expect(loadedConfig, isNotNull);
      expect(loadedConfig!.style.name, config.style.name);
      expect(loadedConfig.difficulty.level, config.difficulty.level);
    });

    test('loadConfig should return null if the config file does not exist', () async {
      // Load the config without saving anything first
      final loadedConfig = await ConfigService.loadConfig();
      expect(loadedConfig, isNull);
    });
  });
}
