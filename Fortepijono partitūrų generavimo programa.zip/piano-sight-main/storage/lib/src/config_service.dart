import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:sheet_music_generator_core/sheet_music_generator_core.dart';

class ConfigService {
  // Path to the config file
  static Future<String> _getConfigFilePath() async {
    final directory = await getApplicationDocumentsDirectory();
    return '${directory.path}/generator_config.json';
  }

  // Save the GeneratorConfig instance to a local JSON file
  static Future<void> saveConfig(GeneratorConfig config) async {
    final filePath = await _getConfigFilePath();

    // Convert the config to JSON and write to file
    try {
      final file = File(filePath);
      String jsonString = jsonEncode(config.toJson());
      await file.writeAsString(jsonString);
    } catch (e) {
      throw Exception('Could not save config');
    }
  }

  // Load a GeneratorConfig instance from a local JSON file
  static Future<GeneratorConfig?> loadConfig() async {
    final filePath = await _getConfigFilePath();

    try {
      final file = File(filePath);
      if (await file.exists()) {
        String jsonString = await file.readAsString();
        final jsonMap = jsonDecode(jsonString);
        return GeneratorConfig.fromJson(jsonMap);
      } else {
        return null; // File does not exist
      }
    } catch (e) {
      throw Exception('Could not load config');
    }
  }
}
